<?php

namespace MobinDev\Novin_Commerce\Digits\SmsGateways;

/**
 * NPSMS (npsms.com) gateway.
 *
 * Sends SMS via a simple GET request to:
 *   https://npsms.com/sendSmsViaURL.aspx?domainName=...&userName=...&password=...
 *       &reciverNumber=...&senderNumber=...&smsText=...
 *
 * All parameter values (domain name, username, password, sender number,
 * and the message text) are user-provided or dynamic, so every one of
 * them is passed through rawurlencode() before being placed in the
 * query string. This keeps Persian text in the message, and any special
 * characters in the password, from corrupting the request.
 */
class Npsms_Gateway implements Sms_Gateway_Interface {

	const ENDPOINT = 'https://npsms.com/sendSmsViaURL.aspx';

	public function get_slug() {
		return 'npsms';
	}

	public function get_label() {
		return 'NPSMS (npsms.com)';
	}

	public function get_settings_fields() {
		return [
			[
				'key'         => 'domain_name',
				'label'       => 'نام دامنه (Domain Name)',
				'type'        => 'text',
				'default'     => '',
				'description' => 'مقدار اختصاصی حساب کاربری شما در NPSMS (پارامتر domainName).',
			],
			[
				'key'         => 'username',
				'label'       => 'نام کاربری (Username)',
				'type'        => 'text',
				'default'     => '',
				'description' => 'نام کاربری پنل NPSMS شما.',
			],
			[
				'key'         => 'password',
				'label'       => 'رمز عبور (Password)',
				'type'        => 'password',
				'default'     => '',
				'description' => 'رمز عبور پنل NPSMS شما. این مقدار در پایگاه‌داده به‌صورت رمزنگاری‌شده ذخیره می‌شود.',
			],
			[
				'key'         => 'sender_number',
				'label'       => 'شماره فرستنده (Sender Number)',
				'type'        => 'text',
				'default'     => '30006403868611',
				'description' => 'شماره خط ارسال‌کننده پیامک. مقدار پیش‌فرض قابل ویرایش است.',
			],
		];
	}

	/**
	 * @inheritDoc
	 */
	public function send( $to, $message, array $settings ) {
		$domain_name   = isset( $settings['domain_name'] ) ? (string) $settings['domain_name'] : '';
		$username      = isset( $settings['username'] ) ? (string) $settings['username'] : '';
		$password      = isset( $settings['password'] ) ? (string) $settings['password'] : '';
		$sender_number = isset( $settings['sender_number'] ) && '' !== $settings['sender_number']
			? (string) $settings['sender_number']
			: '30006403868611';

		if ( '' === $domain_name || '' === $username || '' === $password ) {
			return [
				'success' => false,
				'message' => 'تنظیمات درگاه NPSMS ناقص است (نام دامنه، نام کاربری یا رمز عبور خالی است).',
				'raw'     => '',
			];
		}

		$query = [
			'domainName'    => $domain_name,
			'userName'      => $username,
			'password'      => $password,
			'reciverNumber' => $to,
			'senderNumber'  => $sender_number,
			'smsText'       => $message,
		];

		// Build the query string manually with rawurlencode() on every
		// value (including the password) rather than relying solely on
		// add_query_arg()/http_build_query() defaults, so behavior stays
		// explicit and predictable regardless of WordPress/PHP versions.
		$pairs = [];
		foreach ( $query as $key => $value ) {
			$pairs[] = $key . '=' . rawurlencode( (string) $value );
		}
		$url = self::ENDPOINT . '?' . implode( '&', $pairs );

		$response = wp_remote_get(
			$url,
			[
				'timeout' => 15,
			]
		);

		if ( is_wp_error( $response ) ) {
			return [
				'success' => false,
				'message' => 'خطا در برقراری ارتباط با NPSMS: ' . $response->get_error_message(),
				'raw'     => $response->get_error_message(),
			];
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );

		// NPSMS's sendSmsViaURL.aspx returns a plain-text body. A numeric,
		// non-negative value generally indicates a message id / success on
		// this class of legacy ASP.NET SMS gateways; anything else (an
		// error code or error text) is treated as a failure. Since exact
		// success/error codes are not publicly documented for this
		// endpoint, this check intentionally stays conservative and the
		// full raw response is always logged so failures remain
		// diagnosable from the sync log.
		$trimmed_body = trim( (string) $body );
		$is_success   = ( 200 === (int) $code )
			&& '' !== $trimmed_body
			&& is_numeric( $trimmed_body )
			&& (float) $trimmed_body >= 0;

		return [
			'success' => $is_success,
			'message' => $is_success
				? 'پیامک با موفقیت ارسال شد (پاسخ سرور: ' . $trimmed_body . ').'
				: 'ارسال پیامک ناموفق بود. پاسخ سرور: ' . ( '' !== $trimmed_body ? $trimmed_body : '(خالی) کد HTTP: ' . $code ),
			'raw'     => $trimmed_body,
		];
	}
}
