# NovinCommerce 2.2.2

## Stock repair

Inventory is read from `WebPrd.PrdAnbarRelation[].Amount` and summed. `Mojodi` is used only when no relation amounts exist. The calculated quantity is stored in `_novin_accounting_stock` for display and sorting.

Simple and composite products use WooCommerce managed stock. Variable parent products do not use parent managed stock. Their stock status is derived from the accounting parent quantity or available variations. Variations with their own accounting data use their own quantity.

A background backfill repairs existing synced products. No manual database division or multiplication is required.

## Dashboard

The dashboard keeps six catalog KPIs and three compact charts. The system section contains only unique metrics. The old duplicate total-product metric is removed. The price-level section is compressed into a compact number/progress layout.
