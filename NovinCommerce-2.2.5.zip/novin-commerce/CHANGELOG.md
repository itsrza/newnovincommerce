## 2.2.3
- Added a dedicated product thumbnail column next to the product name.
- Expanded admin pages to use the available content width.
- Refined stock and sync-time header alignment and sorting indicator placement.

## 2.2.2
- اصلاح موجودی WooCommerce و موجودی نمایش داده‌شده در NovinCommerce بر اساس `PrdAnbarRelation[].Amount` با fallback به `Mojodi`.
- افزودن موجودی حسابداری canonical برای Sort صحیح.
- اصلاح وضعیت موجودی محصولات ساده و مرکب.
- اصلاح مدل موجودی محصول متغیر: والد مدیریت موجودی ندارد و وضعیت از منبع/تنوع‌ها تعیین می‌شود.
- بازسازی موجودی کالاهای قبلی به‌صورت پس‌زمینه.
- حذف تکرار «کل محصولات» از وضعیت سیستم داشبورد.
- فشرده‌سازی بخش «دارای سطوح قیمت» و حفظ نمودارهای داشبورد.
- اصلاح راست‌چین بودن قیمت و موجودی و چپ‌چین بودن زمان همگام‌سازی.
