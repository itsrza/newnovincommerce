<?php
namespace Novinwp\Novin_Commerce\Common;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Stock_Sync {
	const SOURCE_META='WebPrd';
	const STOCK_META='_novin_accounting_stock';
	const HASH_META='_novin_stock_sync_hash';
	const BACKFILL_HOOK='novin_commerce_stock_backfill';
	const BACKFILL_VERSION='2.2.2';
	const CURSOR_OPT='novin_commerce_stock_backfill_cursor';
	private static $booted=false;
	private static $locks=array();

	public static function boot(){
		if(self::$booted||!function_exists('wc_get_product'))return;
		self::$booted=true;
		add_action('added_post_meta',array(__CLASS__,'on_webprd_meta_change'),20,4);
		add_action('updated_post_meta',array(__CLASS__,'on_webprd_meta_change'),20,4);
		add_action('save_post_product',array(__CLASS__,'on_product_save'),90,3);
		add_action('save_post_product_variation',array(__CLASS__,'on_variation_save'),90,3);
		add_action(self::BACKFILL_HOOK,array(__CLASS__,'run_backfill'));
		add_action('admin_init',array(__CLASS__,'maybe_admin_backfill'),20);
		self::ensure_backfill_scheduled();
	}
	public static function on_webprd_meta_change($meta_id,$post_id,$meta_key,$meta_value){if(self::SOURCE_META!==$meta_key)return;$post_id=absint($post_id);if(!$post_id||!in_array(get_post_type($post_id),array('product','product_variation'),true))return;self::sync_item($post_id);}
	public static function on_product_save($post_id,$post,$update){if(wp_is_post_revision($post_id)||wp_is_post_autosave($post_id)||'product'!==get_post_type($post_id))return;if(get_post_meta($post_id,self::SOURCE_META,true))self::sync_item($post_id);}
	public static function on_variation_save($post_id,$post,$update){if(wp_is_post_revision($post_id)||wp_is_post_autosave($post_id)||'product_variation'!==get_post_type($post_id))return;if(get_post_meta($post_id,self::SOURCE_META,true))self::sync_item($post_id);}
	public static function sync_item($post_id){$post_id=absint($post_id);if(!$post_id||isset(self::$locks[$post_id]))return false;self::$locks[$post_id]=true;try{$type=get_post_type($post_id);if('product_variation'===$type)return self::sync_variation($post_id);if('product'===$type)return self::sync_product($post_id);return false;}finally{unset(self::$locks[$post_id]);}}
	private static function sync_product($id){$p=wc_get_product($id);if(!$p)return false;$raw=get_post_meta($id,self::SOURCE_META,true);$stock=self::extract_stock($raw);if(null!==$stock)update_post_meta($id,self::STOCK_META,self::num($stock));
		if($p->is_type('variable')){
			foreach((array)$p->get_children() as $vid){$vid=absint($vid);if($vid&&get_post_meta($vid,self::SOURCE_META,true))self::sync_variation($vid);}
			// Parent is never stock-managed. Prefer accounting parent quantity; when absent, derive from child stock.
			$parent_stock=null!==$stock?$stock:self::sum_children_stock($p);
			self::apply_variable_parent($p,$parent_stock);
			return true;
		}
		if(null===$stock)return false;
		self::apply_managed($p,$stock);self::mark($id,$raw);return true;}
	private static function sync_variation($id){$v=wc_get_product($id);if(!$v||!$v->is_type('variation'))return false;$raw=get_post_meta($id,self::SOURCE_META,true);$stock=self::extract_stock($raw);if(null===$stock)return false;update_post_meta($id,self::STOCK_META,self::num($stock));self::apply_managed($v,$stock);self::mark($id,$raw);$pid=absint($v->get_parent_id());if($pid){$parent=wc_get_product($pid);if($parent&&$parent->is_type('variable'))self::sync_product_parent_only($parent);}$dummy=true;return true;}
	private static function sync_product_parent_only($p){$stock=self::extract_stock(get_post_meta($p->get_id(),self::SOURCE_META,true));if(null!==$stock)update_post_meta($p->get_id(),self::STOCK_META,self::num($stock));self::apply_variable_parent($p,null!==$stock?$stock:self::sum_children_stock($p));}
	private static function sum_children_stock($p){$sum=0.0;$has=false;foreach((array)$p->get_children() as $vid){$v=wc_get_product($vid);if(!$v)continue;$q=$v->get_stock_quantity();if(null===$q)continue;$sum+=(float)$q;$has=true;}return $has?$sum:null;}
	private static function apply_variable_parent($p,$stock){$status='outofstock';if(null!==$stock&&((float)$stock>0))$status='instock';else{$has=$p->get_children();foreach((array)$has as $vid){$v=wc_get_product($vid);if($v&&'instock'===$v->get_stock_status()&&(null===$v->get_stock_quantity()||(float)$v->get_stock_quantity()>0)){$status='instock';break;}}}
		$changed=false;if($p->get_manage_stock()){ $p->set_manage_stock(false);$changed=true;}if(null!==$p->get_stock_quantity()){$p->set_stock_quantity(null);$changed=true;}if($p->get_stock_status()!==$status){$p->set_stock_status($status);$changed=true;}if($changed)$p->save();wc_delete_product_transients($p->get_id());}
	private static function apply_managed($p,$stock){$stock=max(0,(float)$stock);$status=$stock>0?'instock':'outofstock';$changed=false;if(!$p->get_manage_stock()){$p->set_manage_stock(true);$changed=true;}if(null===$p->get_stock_quantity()||abs((float)$p->get_stock_quantity()-$stock)>0.000001){$p->set_stock_quantity($stock);$changed=true;}if($p->get_stock_status()!==$status){$p->set_stock_status($status);$changed=true;}if($changed)$p->save();wc_delete_product_transients($p->get_id());}
	public static function extract_stock($raw){$d=self::decode($raw);if(!is_array($d))return null;$has=false;$sum=0.0;if(!empty($d['PrdAnbarRelation'])&&is_array($d['PrdAnbarRelation']))foreach($d['PrdAnbarRelation'] as $r){if(!is_array($r)||!array_key_exists('Amount',$r))continue;$n=self::numeric($r['Amount']);if(null===$n)continue;$has=true;$sum+=(float)$n;}if($has)return max(0,$sum);if(array_key_exists('Mojodi',$d)){ $n=self::numeric($d['Mojodi']);if(null!==$n)return max(0,$n);}return null;}
	public static function get_accounting_stock($id){return self::extract_stock(get_post_meta(absint($id),self::SOURCE_META,true));}
	public static function display_stock($product){if(!$product||!is_object($product))return null;$v=self::get_accounting_stock($product->get_id());if(null!==$v)return $v;$q=$product->get_stock_quantity();return null===$q?null:(float)$q;}
	private static function mark($id,$raw){update_post_meta($id,self::HASH_META,md5((string)$raw));}
	private static function num($n){$f=(float)$n;return abs($f-round($f))<0.000001?(string)(int)round($f):rtrim(rtrim(number_format($f,6,'.',''),'0'),'.');}
	private static function numeric($v){if(is_int($v)||is_float($v))return(float)$v;if(!is_string($v))return null;$v=strtr(trim($v),array('۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9'));$v=str_replace(array(',','٬',' '),'',$v);return is_numeric($v)?(float)$v:null;}
	private static function decode($raw){if(!is_string($raw)||''===trim($raw)||strlen($raw)>1000000)return null;$d=json_decode($raw,true,20);return JSON_ERROR_NONE===json_last_error()&&is_array($d)?$d:null;}
	private static function ensure_backfill_scheduled(){if(self::BACKFILL_VERSION===(string)get_option('novin_commerce_stock_backfill_version',''))return;update_option('novin_commerce_stock_backfill_version',self::BACKFILL_VERSION,false);delete_option(self::CURSOR_OPT);self::schedule_backfill();}
	public static function schedule_backfill(){if(function_exists('as_next_scheduled_action')&&function_exists('as_schedule_single_action')){if(!as_next_scheduled_action(self::BACKFILL_HOOK,array(),'novin-commerce'))as_schedule_single_action(time()+10,self::BACKFILL_HOOK,array(),'novin-commerce');return;}if(!wp_next_scheduled(self::BACKFILL_HOOK))wp_schedule_single_event(time()+20,self::BACKFILL_HOOK);}
	public static function maybe_admin_backfill(){if(!current_user_can('manage_woocommerce'))return;if(self::BACKFILL_VERSION===(string)get_option('novin_commerce_stock_backfill_complete',''))return;$last=(int)get_option(self::CURSOR_OPT,0);if($last<1&&get_transient('novin_commerce_stock_admin_tick'))return;set_transient('novin_commerce_stock_admin_tick',1,10);self::run_backfill();}
	public static function run_backfill(){global $wpdb;$cursor=absint(get_option(self::CURSOR_OPT,0));$ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT p.ID FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} m ON m.post_id=p.ID AND m.meta_key=%s WHERE p.post_type='product' AND p.post_status='publish' AND p.ID>%d AND m.meta_value<>'' ORDER BY p.ID ASC LIMIT 40",self::SOURCE_META,$cursor));if(empty($ids)){delete_option(self::CURSOR_OPT);update_option('novin_commerce_stock_backfill_complete',self::BACKFILL_VERSION,false);Product_Classifier::clear_cache();return;}foreach($ids as $id)self::sync_item(absint($id));update_option(self::CURSOR_OPT,(int)end($ids),false);self::schedule_backfill();Product_Classifier::clear_cache();}
}
