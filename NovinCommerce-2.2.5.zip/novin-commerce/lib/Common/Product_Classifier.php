<?php

namespace Novinwp\Novin_Commerce\Common;

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Product_Classifier {
	const CACHE_KEY = 'novin_commerce_product_classifier_v222';
	const CACHE_TTL = 60;

	public static function counts() {
		$cached = get_transient( self::CACHE_KEY );
		if ( is_array( $cached ) && isset( $cached['simple'] ) ) return $cached;
		global $wpdb;
		$c = array( 'simple'=>0, 'variable'=>0, 'composite'=>0, 'multi_unit'=>0, 'price_levels'=>0, 'variations'=>0, 'total_products'=>0 );
		$c['variations'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='product_variation' AND post_status='publish'" );
		$rows = $wpdb->get_results( "SELECT DISTINCT p.ID, COALESCE(t.slug,'simple') product_type, w.meta_value webprd
			FROM {$wpdb->posts} p
			LEFT JOIN {$wpdb->term_relationships} tr ON tr.object_id=p.ID
			LEFT JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id AND tt.taxonomy='product_type'
			LEFT JOIN {$wpdb->terms} t ON t.term_id=tt.term_id
			LEFT JOIN {$wpdb->postmeta} w ON w.post_id=p.ID AND w.meta_key='WebPrd'
			WHERE p.post_type='product' AND p.post_status='publish'" );
		$seen=array();
		foreach((array)$rows as $r){$id=absint($r->ID);if(!$id||isset($seen[$id]))continue;$seen[$id]=1;$type=self::classify_data((string)$r->product_type,$r->webprd);if(isset($c[$type]))$c[$type]++;if(self::has_price_levels_data($r->webprd))$c['price_levels']++;}
		$c['total_products']=count($seen);
		set_transient(self::CACHE_KEY,$c,self::CACHE_TTL);
		return $c;
	}
	public static function clear_cache(){delete_transient(self::CACHE_KEY);}
	public static function classify_product($product){if(!$product||!is_object($product))return 'simple';if(method_exists($product,'is_type')&&$product->is_type('variation'))return 'variation';$raw=method_exists($product,'get_meta')?$product->get_meta('WebPrd',true):'';return self::classify_data($product->is_type('variable')?'variable':'simple',$raw);}
	public static function classify_data($wc_type,$raw){$d=self::decode($raw);if(is_array($d)){$kind=isset($d['Kind'])&&is_numeric($d['Kind'])?(int)$d['Kind']:0;$tolid=isset($d['TolidFormulaGuid'])?trim((string)$d['TolidFormulaGuid']):'';if(2===$kind||''!==$tolid)return 'composite';if('variable'===$wc_type&&self::has_multi_unit($d))return 'multi_unit';}return 'variable'===$wc_type?'variable':'simple';}
	public static function has_price_levels_data($raw){$d=self::decode($raw);if(!is_array($d))return false;if(!empty($d['PriceRoleList'])&&is_array($d['PriceRoleList']))foreach($d['PriceRoleList'] as $row)if(is_array($row)&&isset($row['Price'])&&is_numeric($row['Price'])&&(float)$row['Price']>0)return true;for($i=1;$i<=8;$i++){ $k='Sell'.$i;if(isset($d[$k])&&is_numeric($d[$k])&&(float)$d[$k]>0)return true;}return false;}
	private static function has_multi_unit(array $d){foreach(array('V2Guid','V3Guid') as $k)if(!empty($d[$k]))return true;foreach(array('V2Qt','V3Qt') as $k)if(isset($d[$k])&&is_numeric($d[$k])&&(float)$d[$k]>0)return true;return false;}
	private static function decode($raw){if(!is_string($raw)||''===trim($raw)||strlen($raw)>500000)return array();$d=json_decode($raw,true,12);return JSON_ERROR_NONE===json_last_error()&&is_array($d)?$d:array();}
}
