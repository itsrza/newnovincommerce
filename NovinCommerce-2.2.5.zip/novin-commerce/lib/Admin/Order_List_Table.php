<?php

namespace Novinwp\Novin_Commerce\Admin;

class Order_List_Table extends List_Table {
	protected $name = 'order';

// just the barebone implementation.
	public function get_columns() {
		return [
			'name'      => 'شماره سفارش',
			'user'      => 'نام سفارش‌دهنده',
			'total'     => 'مبلغ',
			'guid'      => 'شناسه حسابداری',
			'sync_date' => 'زمان همگام‌سازی',
		];
	}

	/**
	 * @param \WC_Order $item
	 * @param string $column_name
	 *
	 * @return mixed|void
	 */
	public function column_default( $item, $column_name ) {
		switch ( $column_name ) {
			case 'name':
				return '<a href="' . esc_url( $item->get_edit_order_url() ) . '">#' . absint( $item->get_id() ) . '</a>';
			case 'total':
				$total = $item->get_total();
				return function_exists( 'wc_price' ) ? wc_price( $total ) : esc_html( (string) $total );
			case 'user':
				$name = trim( $item->get_formatted_billing_full_name() );
				return '' !== $name ? esc_html( $name ) : 'مهمان';
		}
	}


	public function get_sortable_columns() {
		return [
			'name'      => 'name',
			'total'     => 'total',
			'user'      => 'user',
			'guid'      => 'guid',
			'sync_date' => 'sync_date',

		];
	}


	public function fetchTableData() {
		$query_args = [];
		$search     = isset( $_REQUEST['s'] ) ? wp_unslash( trim( $_REQUEST['s'] ) ) : null;

		if ( $search ) {
			$query_args['like_name'] = $search;
		}

		$query = new \WC_Order_Query(
			array_merge(
				[ 'limit' => - 1 ],
				$query_args
			)
		);

		return $query->get_orders();
	}

	/**
	 * @param \WC_Order $item
	 *
	 * @return mixed
	 */
	function getName( $item ) {
		return '#'.$item->get_id();
	}

	function getSyncDate( $item ) {
		return $item->get_meta( '_np-api-sync-date' );
	}

	function getID( $item ) {
		return $item->get_id();
	}

	function getGUID( $item ) {
		return $item->get_meta( 'guid' );
	}
}
