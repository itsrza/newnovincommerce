<?php
namespace Novinwp\Novin_Commerce\Admin;

use Novinwp\Novin_Commerce\Plugin;

/**
 * The accounting-to-site push workflow is not implemented yet. Keep this
 * screen deliberately empty until the future targeted refresh workflow exists.
 */
class Sync_Menu {
    protected $plugin;
    public function __construct( Plugin $plugin ) { $this->plugin = $plugin; }
    public function load() {}
    public function output() {
        echo '<div class="wrap novin-sync-page" dir="rtl"><h1>همگام‌سازی‌ها</h1></div>';
    }
}
