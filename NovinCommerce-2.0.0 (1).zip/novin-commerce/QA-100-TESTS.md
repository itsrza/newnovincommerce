# NovinCommerce 2.0.0 — QA Audit

## Currency safety regression — 2.0.0

- تنظیم `novin_toman_conversion_enabled` دیگر در رابط کاربری وجود ندارد.
- هیچ runtime hook مربوط به تقسیم یا ضرب قیمت برای تبدیل ریال/تومان ثبت نمی‌شود.
- فیلدهای قیمت نقش‌ها مقدار را بدون تبدیل ذخیره می‌کنند.
- موتور قیمت نقش‌ها مقدار ذخیره‌شده را بدون تبدیل به WooCommerce، variation cache و cart می‌دهد.
- در ارتقا فقط کلید تنظیم legacy از آرایه تنظیمات حذف می‌شود؛ قیمت کالا، قیمت نقش و سفارش به‌صورت حدسی تغییر نمی‌کند.


## Scope

این فایل نتیجه تست‌های static/structural نسخه 2.0.0 را ثبت می‌کند. تست runtime کامل فقط روی staging WordPress + WooCommerce و با داده واقعی حسابداری معتبر است.

## Verified in build environment

- PHP syntax validation for all non-vendor PHP files.
- Composer manifest/lock consistency checks.
- Detection of front-end product-render sync hooks.
- Detection of unbounded `limit=-1` / fixed dashboard sample logic.
- Validation of queue item type before lock creation.
- Health index schema presence and migration paths.
- Separation of Variable, Variation, Multi-Unit and Composite modes.
- `Mojodi` is not used as warehouse total.
- Inventory totals use explicit `PrdAnbarRelation[].Amount` only.
- Sell1..Sell8 are not mapped to WordPress roles by array position.
- Manual role prices and sales are not deleted by accounting sync without ownership metadata.
- Accounting discount dates are evaluated before sale activation/removal.
- Multi-Unit requires explicit unit conversion data and unit attribute mapping.
- Variable parent stock is aggregate-only.
- Singleton sync instances prevent duplicate hook registration during background migration.
- HPOS compatibility declaration remains present.

## Runtime limitation

این build بدون اتصال مستقیم به یک WordPress staging فعال، نمی‌تواند موفقیت runtime همه سناریوهای WooCommerce، cron، REST، queue، order stock reduction، HPOS و accounting API را اثبات کند. بنابراین هیچ ادعای «100/100 runtime» ارائه نمی‌شود.

## Release gate

نسخه 2.0.0 از نظر source-level برای بسته‌بندی آماده است؛ پیش از production، باید روی staging با چهار fixture کلیدی و حداقل یک سفارش Multi-Unit تست شود.
