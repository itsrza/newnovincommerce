# Compatibility — NovinCommerce 2.0.0

## Required

- WordPress 6.1 or newer
- WooCommerce installed and active
- PHP 7.4 or newer according to the plugin package metadata

## Recommended for the current Novin Pardaz environment

- PHP 8.2+
- Current supported WooCommerce release
- InnoDB database tables
- UTF-8/utf8mb4 database charset

## WooCommerce-specific behavior

- HPOS-aware order handling is retained.
- Product and variation operations use WooCommerce CRUD APIs.
- Variable parent stock is aggregate-only in v2.

## External accounting data

The implementation expects `WebPrd` JSON with fields such as:

- `Guid`
- `Modified`
- `PrdAnbarRelation[].Amount`
- `Sell1..Sell8`
- `Prices[].Price` and `Prices[].PriceLevelGuid`
- `PriceRoleList`
- optional unit conversion fields `V2Qt`, `V3Qt`, `V2Guid`, `V3Guid`
- optional discount fields

When required accounting fields are absent or invalid, the Health Index reports an unknown/attention state instead of inventing a value.
