# Security — NovinCommerce 2.0.0

## Principles

- Never log API secrets, access tokens, consumer secrets or passwords.
- Admin actions require the appropriate capability and nonce.
- REST/AJAX input is validated and failures return safe messages.
- Sensitive configuration should be stored outside source code and encrypted where the existing subsystem supports it.
- The frontend does not trigger accounting read/sync operations during product rendering.
- Uninstall is non-destructive to generic WooCommerce metadata.

## Reporting a security issue

Report security issues privately to the Novin Pardaz development/operations team before public disclosure.

Do not include API credentials, customer data, authentication cookies or production database dumps in a report.
