=== Plugin Name ===
NovinCommerce - 2.0.0
Contributors: novinwp
Donate link: https://npwp.ir/
Tags: woocommerce, accounting, inventory, product sync, role pricing, multi unit
Requires at least: 6.1
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

اتصال حسابداری نوین پرداز به WooCommerce با مدل داده استاندارد، موجودی انبار، سطوح قیمت حسابداری، قیمت‌گذاری نقش‌ها، Multi-Unit و داشبورد سلامت داده.

== Description ==

NovinCommerce داده‌های حسابداری نوین پرداز را با WooCommerce همگام می‌کند.

نسخه 2.0.0 یک بازطراحی معماری است. مهم‌ترین تغییرات:

* موجودی کل از ردیف‌های معتبر `PrdAnbarRelation[].Amount` محاسبه می‌شود؛ `WebPrd.Mojodi` به‌عنوان موجودی کل استفاده نمی‌شود.
* Variable Product، Variation، Multi-Unit و ماهیت حسابداری محصول از یکدیگر جدا شده‌اند.
* محصول Variable والد فقط نقش Aggregate دارد و موجودی مستقل صفر روی والد باعث ناموجود شدن همه Variations نمی‌شود.
* `V2Qt` و `V3Qt` به‌صورت مستقل پردازش می‌شوند و ترتیب Variationها مبنای تبدیل واحد نیست.
* `Sell1` تا `Sell8` به‌عنوان سطوح قیمت حسابداری پردازش می‌شوند و `PriceRoleList` نگاشت مستقل نقش‌های WordPress است.
* قیمت‌های دستی حذف نمی‌شوند. مالکیت قیمت و sale با metadata داخلی مشخص می‌شود.
* تخفیف حسابداری فقط در صورت وجود برنامه زمانی معتبر فعال است و تخفیف دستی بدون مالکیت حسابداری حفظ می‌شود.
* Sync در زمان رندر فرانت‌اند انجام نمی‌شود.
* داشبورد بر پایه Health Index پایدار و وضعیت‌های قابل اقدام است و نسبت گمراه‌کننده Product/Variation یا health score ساختگی ندارد.
* مهاجرت نسخه 2.0.0 مرحله‌ای و محدود است تا روی درخواست وب سنگین اجرا نشود.

== Installation ==

1. از سایت و پایگاه داده نسخه پشتیبان تهیه کنید.
2. فایل ZIP نسخه 2.0.0 را از بخش Plugins > Add New > Upload Plugin نصب کنید یا پوشه افزونه را در `wp-content/plugins/` قرار دهید.
3. افزونه را فعال یا به نسخه 2.0.0 ارتقا دهید.
4. در صورت ارتقا، migration پس‌زمینه را تا تکمیل Health Index متوقف نکنید.
5. در WooCommerce > NovinCommerce > تنظیمات، در صورت نیاز محدوده GUID انبارهای مورد استفاده برای محاسبه موجودی را تنظیم کنید.

== Important upgrade note ==

نسخه 2.0.0 رفتار موجودی، قیمت‌گذاری و تخفیف را دقیق‌تر می‌کند. قبل از ارتقا از داده‌های سایت نسخه پشتیبان بگیرید و ابتدا روی staging آزمایش کنید.

== Health model ==

داشبورد موارد زیر را به‌صورت وضعیت عملیاتی گزارش می‌کند:

* GUID ناقص یا مغایر
* WebPrd نامعتبر
* داده stale یا زمان Sync نامشخص
* موجودی بدون `Amount` معتبر
* Multi-Unit با نگاشت مبهم
* sale حسابداری منقضی یا نامعتبر که مالکیت آن مشخص است

== Pricing model ==

`Sell1..Sell8` هشت سطح قیمت حسابداری هستند. این سطوح با نقش‌های WordPress یکی نیستند. `PriceRoleList` فقط نقش‌هایی را نگاشت می‌کند که حسابداری برای آن‌ها mapping صریح ارائه کرده است. هیچ mapping بر اساس ترتیب آرایه `Prices[]` انجام نمی‌شود.

== Inventory model ==

برای موجودی انبار فقط `PrdAnbarRelation[].Amount` معتبر مبنای محاسبه است. نبود Amount معتبر به معنی موجودی صفر نیست و `Mojodi` به‌جای آن استفاده نمی‌شود.

برای محصولات Multi-Unit، موجودی پایه در واحد حسابداری محاسبه و سپس با `V2Qt` و `V3Qt` به Variation متناظر تبدیل می‌شود.

== Changelog ==

= 2.0.0 =
* بازطراحی مدل داده حسابداری و افزودن Health Index پایدار.
* اصلاح محاسبه موجودی بر اساس `PrdAnbarRelation[].Amount`.
* تفکیک Variable، Variation، Multi-Unit و Composite/Production.
* اصلاح تبدیل واحد با تفکیک مستقل V2 و V3.
* تفکیک هشت سطح قیمت حسابداری از mapping نقش‌های WordPress.
* حفظ قیمت‌ها و saleهای دستی با tracking مالکیت.
* اصلاح lifecycle تخفیف حسابداری.
* حذف Sync در زمان رندر فرانت‌اند و کنترل loopهای داخلی.
* بازطراحی داشبورد و migration مرحله‌ای.
* بهبود امنیت AJAX/REST، HPOS، queue locking، lifecycle پاک‌سازی و uninstall.

= 1.20.0 =
* انتشار نسخه 1.20.0 با بازسازی namespace و زیرساخت Composer.
