<?php

namespace Novinwp\Novin_Commerce\Admin;

use Novinwp\Novin_Commerce\Common\Accounting_Data;
use Novinwp\Novin_Commerce\Common\Health_Snapshot;
use Novinwp\Novin_Commerce\Common\SettingAPI;
use Novinwp\Novin_Commerce\Common\SyncLog;
use Novinwp\Novin_Commerce\Models\Sync;
use Novinwp\Novin_Commerce\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Operational dashboard. It deliberately avoids misleading catalogue ratios
 * and presents only actionable states backed by the persistent health index.
 */
class Connection_Dashboard {

	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'دسترسی غیرمجاز.', 'novin-commerce' ) );
		}

		self::handle_actions();
		$data = self::view_model();
		$plugin_file = dirname( __DIR__, 2 ) . '/novin-commerce.php';
		wp_enqueue_style( 'novin-commerce-admin-table', plugins_url( 'dist/styles/admin/table.min.css', $plugin_file ), array(), '2.0.0' );
		wp_add_inline_style( 'novin-commerce-admin-table', self::css() );

		?>
		<div class="wrap novin-v2-dashboard" dir="rtl">
			<div class="novin-v2-header">
				<div>
					<span class="novin-v2-eyebrow">NOVIN COMMERCE 2.0</span>
					<h1>مرکز کنترل اتصال حسابداری</h1>
					<p>داشبورد فقط وضعیت‌هایی را نشان می‌دهد که برای تصمیم‌گیری یا اقدام عملی معنا دارند.</p>
				</div>
				<div class="novin-v2-actions">
					<?php self::action_form( 'scan', 'اسکن سلامت داده', 'button' ); ?>
					<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=novin-commerce-products' ) ); ?>">کالاها</a>
					<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=novin-commerce-syncs' ) ); ?>">صف تبادل<?php echo $data['queue_total'] ? ' (' . number_format_i18n( $data['queue_total'] ) . ')' : ''; ?></a>
					<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=novin-commerce-settings' ) ); ?>">تنظیمات</a>
				</div>
			</div>

			<div class="novin-v2-kpis">
				<?php self::kpi( 'اتصال API', $data['api']['status'], $data['api']['detail'], $data['api']['tone'] ); ?>
				<?php self::kpi( 'موارد نیازمند اقدام', number_format_i18n( $data['attention'] ), $data['attention'] ? 'برای هر مورد، علت و مسیر اقدام مشخص شده است.' : 'مورد بحرانی در ایندکس سلامت ثبت نشده است.', $data['attention'] ? 'warning' : 'success' ); ?>
				<?php self::kpi( 'صف تبادل', number_format_i18n( $data['queue_total'] ), $data['queue_total'] ? 'مورد در صف انتظار یا بازپردازش است.' : 'صف خالی است.', $data['queue_total'] ? 'warning' : 'success' ); ?>
				<?php self::kpi( 'آخرین زمان دریافت', $data['last_sync'], 'مرجع ذخیره‌شده در تنظیمات اتصال.', $data['last_sync'] === 'ثبت نشده' ? 'warning' : 'info' ); ?>
			</div>

			<div class="novin-v2-grid">
				<section class="novin-v2-panel novin-v2-wide">
					<div class="novin-v2-title"><div><span class="novin-v2-eyebrow">ACTION CENTER</span><h2>مواردی که واقعاً باید بررسی شوند</h2><p>عددها از ایندکس سلامت پایدار می‌آیند؛ نمایش «نمونه ۱۵۰ کالا» در v2 حذف شده است.</p></div></div>
					<div class="novin-v2-issues">
						<?php self::issue( 'شناسه حسابداری ثبت نشده', $data['health']['guid_missing'], 'کالاهایی که داده حسابداری دارند اما GUID سایت آن‌ها خالی است.', 'products' ); ?>
						<?php self::issue( 'مغایرت GUID', $data['health']['guid_mismatch'], 'GUID حسابداری و GUID سایت یکسان نیستند. قبل از اصلاح، تطبیق منبع را بررسی کنید.', 'products' ); ?>
						<?php self::issue( 'داده WebPrd نامعتبر', $data['health']['webprd_invalid'], 'JSON حسابداری قابل خواندن نیست یا ساختار مورد انتظار را ندارد.', 'products' ); ?>
						<?php self::issue( 'همگام‌سازی عقب‌مانده', $data['health']['stale'], 'Modified حسابداری جدیدتر از زمان آخرین دریافت سایت است.', 'products' ); ?>
						<?php self::issue( 'زمان همگام‌سازی ثبت نشده', $data['health']['sync_unknown'], 'برای WebPrd معتبر، زمان دریافت سایت ثبت نشده است؛ تازگی داده قابل اثبات نیست.', 'products' ); ?>
						<?php self::issue( 'موجودی نامشخص', $data['health']['inventory_unknown'], 'PrdAnbarRelation Amount معتبر وجود ندارد؛ Mojodi به‌جای آن استفاده نمی‌شود.', 'products' ); ?>
						<?php self::issue( 'نگاشت Multi-Unit مبهم', $data['health']['multi_unit_ambiguous'], 'واحدهای V2/V3 بدون نگاشت صریح به variation قابل اعتماد نیستند.', 'products' ); ?>
						<?php self::issue( 'تخفیف حسابداری منقضی/نامعتبر', $data['health']['discount_actionable'], 'فقط تخفیف‌هایی که مالکیت حسابداری آن‌ها مشخص است قابل حذف خودکار هستند.', 'products' ); ?>
					</div>
				</section>

				<section class="novin-v2-panel">
					<div class="novin-v2-title"><div><span class="novin-v2-eyebrow">CATALOG MODEL</span><h2>ساختار کاتالوگ</h2><p>سطوح معنایی از یکدیگر جدا هستند؛ نسبت Product/Variation نمایش داده نمی‌شود.</p></div></div>
					<div class="novin-v2-stats">
						<?php self::stat( 'محصول ساده منتشرشده', $data['catalog']['simple'] ); ?>
						<?php self::stat( 'محصول متغیر والد', $data['catalog']['variable'] ); ?>
						<?php self::stat( 'Variation', $data['catalog']['variations'] ); ?>
						<?php self::stat( 'Multi-Unit', $data['health']['multi_unit'] ); ?>
						<?php self::stat( 'Composite / تولیدی', $data['health']['composite'] ); ?>
						<?php self::stat( 'Draft', $data['catalog']['draft'] ); ?>
					</div>
				</section>

				<section class="novin-v2-panel">
					<div class="novin-v2-title"><div><span class="novin-v2-eyebrow">ACCOUNTING PRICING</span><h2>سطوح قیمتی حسابداری</h2><p>Sell1 تا Sell8 «سطح قیمت» هستند، نه نقش کاربری. PriceRoleList نگاشت مستقل نقش‌هاست.</p></div></div>
					<div class="novin-v2-price-box">
						<div class="novin-v2-price-main"><strong><?php echo number_format_i18n( $data['health']['price_levels'] ); ?></strong><span>آیتم دارای حداقل یک سطح قیمت حسابداری</span></div>
						<div class="novin-v2-price-rule"><b>قاعده v2</b><span>PriceLevelGuid فقط در صورت تطبیق قطعی با خود Price معتبر است؛ هیچ نگاشتی بر اساس ترتیب آرایه انجام نمی‌شود.</span></div>
						<div class="novin-v2-price-rule"><b>نقش‌های WordPress</b><span>تعداد نقش‌های نگاشت‌شده: <?php echo number_format_i18n( $data['health']['mapped_roles'] ); ?>. نبود Price برای یک نقش، قیمت دستی آن نقش را حذف نمی‌کند.</span></div>
					</div>
				</section>

				<section class="novin-v2-panel novin-v2-wide">
					<div class="novin-v2-title"><div><span class="novin-v2-eyebrow">QUEUE & ACTIVITY</span><h2>صف تبادل و رویدادهای اخیر</h2><p>صف‌بندی و لاگ‌ها از داده‌های واقعی افزونه خوانده می‌شوند.</p></div><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=novin-commerce-syncs' ) ); ?>">مدیریت صف</a></div>
					<div class="novin-v2-two-col">
						<div><?php self::queue_table( $data['queue_counts'] ); ?></div>
						<div><?php self::log_table( $data['logs'] ); ?></div>
					</div>
				</section>

				<section class="novin-v2-panel novin-v2-wide">
					<div class="novin-v2-title"><div><span class="novin-v2-eyebrow">HEALTH INDEX</span><h2>وضعیت ایندکس سلامت</h2><p>ایندکس به‌صورت مرحله‌ای ساخته می‌شود. تا تکمیل ایندکس، عدد «نیازمند اقدام» فقط وضعیت داده‌های ایندکس‌شده را پوشش می‌دهد.</p></div></div>
					<div class="novin-v2-index-row">
						<?php self::index_value( 'ایندکس‌شده', number_format_i18n( $data['health']['indexed'] ) . ' / ' . number_format_i18n( $data['health']['source_objects'] ), $data['health']['complete'] ? 'ایندکس v2 کامل است.' : 'ایندکس هنوز در حال تکمیل است.' ); ?>
						<?php self::index_value( 'سالم', $data['health']['healthy'], 'هیچ پرچم عملیاتی فعال ندارد.' ); ?>
						<?php self::index_value( 'نیازمند اقدام', $data['health']['attention'], 'حداقل یک پرچم عملیاتی فعال دارد.' ); ?>
						<?php self::index_value( 'آخرین ساخت', $data['health_last_build'], $data['health_last_build_detail'] ); ?>
					</div>
				</section>

				<?php if ( ! empty( $data['recent_attention'] ) ) : ?>
				<section class="novin-v2-panel novin-v2-wide">
					<div class="novin-v2-title"><div><span class="novin-v2-eyebrow">NEXT ACTIONS</span><h2>چند مورد بعدی برای بررسی</h2></div></div>
					<div class="novin-v2-attention-list">
						<?php foreach ( $data['recent_attention'] as $row ) : ?>
							<?php self::attention_row( $row ); ?>
						<?php endforeach; ?>
					</div>
				</section>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	private static function view_model() {
		global $wpdb;
		$health = Health_Snapshot::aggregate();
		$product_counts = wp_count_posts( 'product' );
		$products = (int) ( $product_counts->publish ?? 0 );
		$draft    = (int) ( $product_counts->draft ?? 0 );
		$variable = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} p INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id=p.ID INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id INNER JOIN {$wpdb->terms} t ON t.term_id=tt.term_id WHERE p.post_type='product' AND p.post_status='publish' AND tt.taxonomy='product_type' AND t.slug='variable'" );
		$variations = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='product_variation' AND post_status='publish'" );
		$simple = max( 0, $products - $variable );
		$queue_counts = array();
		foreach ( array( 'product' => 'کالای اصلی', 'variation' => 'تنوع', 'order' => 'فاکتور', 'category' => 'دسته‌بندی', 'user' => 'شخص' ) as $type => $label ) {
			$queue_counts[ $type ] = array( 'label' => $label, 'count' => (int) Sync::where( 'item_type', $type )->count() );
		}
		$queue_total = (int) Sync::count();
		$logs = self::logs();
		$api_url = SettingAPI::get( 'api_url', '' );
		$api_ok  = $api_url && wp_http_validate_url( $api_url );
		$sync_ts = (int) SettingAPI::get( 'sync_datetime', 0 );
		return array(
			'api' => array(
				'status' => $api_ok ? 'پیکربندی‌شده' : 'نیازمند بررسی',
				'detail' => $api_ok ? 'نشانی API معتبر و قابل استفاده است.' : 'آدرس API تنظیم نشده یا نامعتبر است.',
				'tone'   => $api_ok ? 'success' : 'error',
			),
			'last_sync' => $sync_ts ? wp_date( 'Y-m-d H:i:s', $sync_ts ) : 'ثبت نشده',
			'queue_total' => $queue_total,
			'queue_counts' => $queue_counts,
			'logs' => $logs,
			'attention' => (int) $health['attention'],
			'catalog' => array( 'products' => $products, 'simple' => $simple, 'variable' => $variable, 'variations' => $variations, 'draft' => $draft ),
			'health' => $health,
			'health_last_build' => $health['last_build'] ? wp_date( 'Y-m-d H:i:s', $health['last_build'] ) : 'هنوز ساخته نشده',
			'health_last_build_detail' => $health['last_build'] ? 'آخرین تغییر در ایندکس ثبت شده است.' : 'پس از فعال‌سازی v2، اسکن پس‌زمینه در حال ساخت ایندکس است.',
			'recent_attention' => Health_Snapshot::recent_attention( 8 ),
		);
	}

	private static function logs() {
		global $wpdb;
		$table = $wpdb->prefix . 'novin_commerce_sync_logs';
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT event_type,status,item_type,item_id,message,created_at FROM {$table} ORDER BY id DESC LIMIT %d", 8 ) );
		return (array) $rows;
	}

	private static function handle_actions() {
		if ( empty( $_POST['novin_dashboard_action'] ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'دسترسی غیرمجاز.', 'novin-commerce' ) );
		}
		check_admin_referer( 'novin_dashboard_action' );
		$action = sanitize_key( wp_unslash( $_POST['novin_dashboard_action'] ) );
		if ( 'scan' === $action ) {
			// The accounting migration updates the persistent health index as it
			// processes each product. Keep one bounded pass per request and reuse
			// the singleton so scan actions never register duplicate hooks.
			if ( class_exists( '\NovinCommerce_RolePrice_Accounting_Sync' ) ) {
				$sync = \NovinCommerce_RolePrice_Accounting_Sync::get_instance();
				if ( ! $sync ) {
					$sync = new \NovinCommerce_RolePrice_Accounting_Sync();
				}
				$sync->migrate_existing_chunk( 40 );
			} else {
				Health_Snapshot::backfill_chunk( 40 );
			}
		}
		wp_safe_redirect( wp_get_referer() ?: admin_url( 'admin.php?page=novin-commerce-dashboard' ) );
		exit;
	}

	private static function action_form( $action, $label, $class = 'button' ) {
		echo '<form method="post" style="display:inline-block">' . wp_nonce_field( 'novin_dashboard_action', '_wpnonce', true, false ) . '<input type="hidden" name="novin_dashboard_action" value="' . esc_attr( $action ) . '"><button class="' . esc_attr( $class ) . '" type="submit">' . esc_html( $label ) . '</button></form>';
	}

	private static function kpi( $label, $value, $detail, $tone ) {
		echo '<div class="novin-v2-kpi tone-' . esc_attr( $tone ) . '"><span>' . esc_html( $label ) . '</span><strong>' . esc_html( $value ) . '</strong><small>' . esc_html( $detail ) . '</small></div>';
	}

	private static function issue( $label, $count, $detail, $target = '' ) {
		unset( $target );
		$count = (int) $count;
		$class = $count ? 'is-bad' : 'is-ok';
		$url = admin_url( 'admin.php?page=novin-commerce-products' );
		echo '<div class="novin-v2-issue ' . $class . '"><div class="novin-v2-issue-icon">' . self::icon( $count ? 'alert' : 'check' ) . '</div><div><strong>' . esc_html( $label ) . '</strong><span>' . number_format_i18n( $count ) . ' مورد</span><small>' . esc_html( $detail ) . '</small></div>';
		if ( $count ) {
			echo '<a href="' . esc_url( $url ) . '">مشاهده کالاها</a>';
		}
		echo '</div>';
	}

	private static function stat( $label, $value ) {
		echo '<div class="novin-v2-stat"><span>' . esc_html( $label ) . '</span><strong>' . number_format_i18n( (int) $value ) . '</strong></div>';
	}

	private static function index_value( $label, $value, $detail ) {
		echo '<div class="novin-v2-index-value"><strong>' . esc_html( $value ) . '</strong><span>' . esc_html( $label ) . '</span><small>' . esc_html( $detail ) . '</small></div>';
	}

	private static function queue_table( $rows ) {
		echo '<table class="widefat striped novin-v2-table"><thead><tr><th>نوع</th><th>تعداد</th></tr></thead><tbody>';
		foreach ( $rows as $row ) {
			echo '<tr><td>' . esc_html( $row['label'] ) . '</td><td>' . number_format_i18n( (int) $row['count'] ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function log_table( $rows ) {
		echo '<table class="widefat striped novin-v2-table"><thead><tr><th>رویداد</th><th>وضعیت</th><th>زمان</th></tr></thead><tbody>';
		if ( empty( $rows ) ) {
			echo '<tr><td colspan="3">رویدادی ثبت نشده است.</td></tr>';
		} else {
			foreach ( $rows as $row ) {
				echo '<tr><td>' . esc_html( $row->event_type ) . '</td><td><span class="novin-v2-status ' . esc_attr( $row->status ) . '">' . esc_html( $row->status ) . '</span></td><td>' . esc_html( $row->created_at ) . '</td></tr>';
			}
		}
		echo '</tbody></table>';
	}

	private static function attention_row( $row ) {
		$id = absint( $row->object_id );
		$product = wc_get_product( $id );
		$name = $product ? $product->get_name() : '#' . $id;
		$reasons = array();
		if ( (int) $row->source_guid_present && ! (int) $row->guid_present ) { $reasons[] = 'GUID ناقص'; }
		if ( (int) $row->source_guid_present && (int) $row->guid_present && ! (int) $row->guid_match ) { $reasons[] = 'مغایرت GUID'; }
		if ( (int) $row->stale ) { $reasons[] = 'Stale'; }
		if ( empty( $row->site_sync ) ) { $reasons[] = 'زمان Sync'; }
		if ( ! (int) $row->inventory_known ) { $reasons[] = 'موجودی نامشخص'; }
		if ( (int) $row->multi_unit_ambiguous ) { $reasons[] = 'Multi-Unit'; }
		if ( (int) $row->discount_actionable ) { $reasons[] = 'تخفیف'; }
		$url = get_edit_post_link( $id, 'raw' );
		echo '<div class="novin-v2-attention"><div><strong>' . esc_html( $name ) . '</strong><small>ID: ' . number_format_i18n( $id ) . ' · ' . esc_html( implode( '، ', $reasons ) ) . '</small></div>';
		if ( $url ) {
			echo '<a class="button" href="' . esc_url( $url ) . '">ویرایش</a>';
		}
		echo '</div>';
	}

	private static function icon( $name ) {
		$icons = array(
			'check' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4 10-10"/></svg>',
			'alert' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 4 9 16H3L12 4Z"/><path d="M12 9v5M12 17h.01"/></svg>',
		);
		return isset( $icons[ $name ] ) ? $icons[ $name ] : '';
	}

	private static function css() {
		return <<<'CSS'
.novin-v2-dashboard{max-width:1400px;margin:20px auto 50px;padding:0 18px;box-sizing:border-box}.novin-v2-dashboard *{box-sizing:border-box}.novin-v2-header{display:flex;justify-content:space-between;gap:22px;align-items:flex-start;background:#fff;border:1px solid #dcdcde;border-radius:18px;padding:24px 26px;margin-bottom:16px}.novin-v2-header h1{margin:5px 0 8px;font-size:28px;line-height:1.25}.novin-v2-header p{margin:0;color:#646970}.novin-v2-eyebrow{display:block;font-size:11px;font-weight:700;letter-spacing:.12em;color:#64748b}.novin-v2-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.novin-v2-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:16px}.novin-v2-kpi{background:#fff;border:1px solid #dcdcde;border-radius:16px;padding:18px;min-height:132px}.novin-v2-kpi span{display:block;color:#646970;font-size:12px}.novin-v2-kpi strong{display:block;font-size:26px;margin:7px 0}.novin-v2-kpi small{display:block;color:#64748b;line-height:1.7}.novin-v2-kpi.tone-error{border-top:4px solid #dc2626}.novin-v2-kpi.tone-warning{border-top:4px solid #d97706}.novin-v2-kpi.tone-success{border-top:4px solid #15803d}.novin-v2-kpi.tone-info{border-top:4px solid #2563eb}.novin-v2-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.novin-v2-panel{background:#fff;border:1px solid #dcdcde;border-radius:16px;padding:20px;min-width:0}.novin-v2-wide{grid-column:1/-1}.novin-v2-title{display:flex;justify-content:space-between;gap:16px;align-items:flex-start;margin-bottom:16px}.novin-v2-title h2{margin:4px 0 6px;font-size:17px}.novin-v2-title p{margin:0;color:#646970;line-height:1.8}.novin-v2-issues{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.novin-v2-issue{display:grid;grid-template-columns:38px 1fr auto;gap:12px;align-items:center;border:1px solid #edf0f3;border-radius:14px;padding:13px}.novin-v2-issue-icon{width:38px;height:38px;border-radius:11px;display:grid;place-items:center;background:#f8fafc}.novin-v2-issue-icon svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}.novin-v2-issue.is-bad{border-color:#fecaca;background:#fffafa}.novin-v2-issue.is-bad .novin-v2-issue-icon{color:#dc2626;background:#fef2f2}.novin-v2-issue.is-ok{background:#fbfffc}.novin-v2-issue.is-ok .novin-v2-issue-icon{color:#15803d;background:#f0fdf4}.novin-v2-issue strong{display:block;font-size:13px}.novin-v2-issue span{display:block;margin-top:2px;font-weight:700;font-size:12px}.novin-v2-issue small{display:block;color:#64748b;line-height:1.7;margin-top:4px}.novin-v2-issue a{font-size:12px;text-decoration:none;white-space:nowrap}.novin-v2-stats{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.novin-v2-stat{padding:14px;border:1px solid #edf0f3;border-radius:12px;background:#fbfcfe}.novin-v2-stat span{display:block;color:#64748b;font-size:11px}.novin-v2-stat strong{display:block;font-size:22px;margin-top:4px}.novin-v2-price-box{display:grid;grid-template-columns:180px 1fr;gap:12px}.novin-v2-price-main,.novin-v2-price-rule{border:1px solid #edf0f3;border-radius:13px;padding:14px;background:#fbfcfe}.novin-v2-price-main strong{display:block;font-size:28px}.novin-v2-price-main span{display:block;color:#64748b;font-size:11px;margin-top:4px}.novin-v2-price-rule b{display:block;font-size:12px;margin-bottom:4px}.novin-v2-price-rule span{display:block;color:#64748b;font-size:11px;line-height:1.8}.novin-v2-two-col{display:grid;grid-template-columns:1fr 1fr;gap:16px}.novin-v2-table{border-collapse:collapse}.novin-v2-table th,.novin-v2-table td{padding:10px 12px!important}.novin-v2-status{font-size:11px;padding:3px 8px;border-radius:999px;background:#f1f5f9}.novin-v2-status.error{background:#fef2f2;color:#b91c1c}.novin-v2-status.success{background:#f0fdf4;color:#166534}.novin-v2-index-row{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.novin-v2-index-value{border:1px solid #edf0f3;border-radius:13px;padding:15px;background:#fbfcfe}.novin-v2-index-value strong{display:block;font-size:23px}.novin-v2-index-value span{display:block;font-weight:700;font-size:12px;margin-top:3px}.novin-v2-index-value small{display:block;color:#64748b;font-size:11px;line-height:1.7;margin-top:5px}.novin-v2-attention-list{display:grid;gap:8px}.novin-v2-attention{display:flex;justify-content:space-between;align-items:center;gap:12px;border:1px solid #edf0f3;border-radius:12px;padding:12px 14px}.novin-v2-attention strong{display:block;font-size:13px}.novin-v2-attention small{display:block;color:#64748b;margin-top:3px}.novin-v2-attention a{white-space:nowrap}@media(max-width:1100px){.novin-v2-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}.novin-v2-price-box{grid-template-columns:1fr}.novin-v2-index-row{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:780px){.novin-v2-header{display:block}.novin-v2-actions{margin-top:16px}.novin-v2-grid,.novin-v2-issues,.novin-v2-two-col{grid-template-columns:1fr}.novin-v2-wide{grid-column:auto}.novin-v2-kpis{grid-template-columns:1fr}.novin-v2-index-row{grid-template-columns:1fr}}
CSS;
	}
}
