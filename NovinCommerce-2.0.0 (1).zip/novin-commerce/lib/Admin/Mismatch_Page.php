<?php

namespace Novinwp\Novin_Commerce\Admin;

use Novinwp\Novin_Commerce\Common\Accounting_Data;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( __NAMESPACE__ . '\\Mismatch_Page' ) ) {

class Mismatch_Page {

	const COUNT_TRANSIENT = 'novin_guid_mismatch_count';
	const CACHE_TTL       = 30 * MINUTE_IN_SECONDS;
	const PAGE_SIZE       = 100;

	/**
	 * Count duplicate product/variation GUID objects.
	 *
	 * @return int
	 */
	public static function getMismatchCount() {
		global $wpdb;

		$cached = get_transient( self::COUNT_TRANSIENT );
		if ( false !== $cached ) {
			return (int) $cached;
		}

		$table = $wpdb->postmeta;
		$count = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$table} m INNER JOIN (\n\t\t\tSELECT meta_value\n\t\t\tFROM {$table}\n\t\t\tWHERE meta_key = 'guid' AND meta_value <> ''\n\t\t\tGROUP BY meta_value\n\t\t\tHAVING COUNT(*) > 1\n\t\t) d ON d.meta_value = m.meta_value WHERE m.meta_key = 'guid'"
		);

		set_transient( self::COUNT_TRANSIENT, $count, self::CACHE_TTL );
		return $count;
	}

	/**
	 * Render paginated GUID mismatch results. WebPrd is read through the
	 * normalized accounting data layer; the full catalog is never loaded at once.
	 */
	public static function renderPage() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'دسترسی غیرمجاز.', 'novin-commerce' ) );
		}

		$plugin_file = dirname( __DIR__, 2 ) . '/novin-commerce.php';
		wp_enqueue_style( 'novin-commerce-admin-table', plugins_url( 'dist/styles/admin/table.min.css', $plugin_file ), array(), '2.0.0' );

		if ( isset( $_GET['novin_refresh'] ) && current_user_can( 'manage_woocommerce' ) ) {
			self::clearCache();
			echo '<div class="notice notice-info"><p>کش مغایرت‌ها پاک شد.</p></div>';
		}

		global $wpdb;

		$page = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1;
		$per_page = self::PAGE_SIZE;
		$offset = ( $page - 1 ) * $per_page;
		$total = self::getMismatchCount();
		$total_pages = max( 1, (int) ceil( $total / $per_page ) );
		$page = min( $page, $total_pages );
		$offset = ( $page - 1 ) * $per_page;

		$rows = array();
		if ( $total > 0 ) {
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT p.ID, p.post_title, p.post_type, m.meta_value AS guid\n\t\t\t\t\tFROM {$wpdb->posts} p\n\t\t\t\t\tINNER JOIN {$wpdb->postmeta} m ON p.ID = m.post_id AND m.meta_key = 'guid' AND m.meta_value <> ''\n\t\t\t\t\tINNER JOIN (\n\t\t\t\t\t\tSELECT meta_value\n\t\t\t\t\t\tFROM {$wpdb->postmeta}\n\t\t\t\t\t\tWHERE meta_key = 'guid' AND meta_value <> ''\n\t\t\t\t\t\tGROUP BY meta_value\n\t\t\t\t\t\tHAVING COUNT(*) > 1\n\t\t\t\t\t) d ON d.meta_value = m.meta_value\n\t\t\t\t\tWHERE p.post_type IN ('product','product_variation')\n\t\t\t\t\tAND p.post_status NOT IN ('trash','auto-draft')\n\t\t\t\t\tORDER BY m.meta_value ASC, p.ID ASC\n\t\t\t\t\tLIMIT %d OFFSET %d",
					$per_page,
					$offset
				)
			);
		}

		echo '<div class="wrap" dir="rtl">';
		echo '<div class="novin-item-header"><div><span class="novin-kicker">NOVIN COMMERCE 2.0</span><h1>مغایرت‌گیری</h1><p>فقط کالاها و Variationهایی نمایش داده می‌شوند که GUID حسابداری آن‌ها با مورد دیگری تکرار شده است.</p></div><a class="button" href="' . esc_url( admin_url( 'admin.php?page=novin-commerce-dashboard' ) ) . '">بازگشت به داشبورد</a></div>';
		echo '<p><a href="' . esc_url( add_query_arg( 'novin_refresh', '1' ) ) . '" class="button">بروزرسانی نتایج</a></p>';

		if ( empty( $rows ) ) {
			echo '<div class="notice notice-success"><p>هیچ مغایرتی یافت نشد.</p></div>';
			echo '</div>';
			return;
		}

		echo '<p style="color:#646970;">' . sprintf( esc_html__( 'نمایش %1$s تا %2$s از %3$s مورد', 'novin-commerce' ), number_format_i18n( $offset + 1 ), number_format_i18n( min( $offset + $per_page, $total ) ), number_format_i18n( $total ) ) . '</p>';
		echo '<table class="widefat striped" style="margin-top:20px;"><thead><tr><th>عنوان پست</th><th>نوع پست</th><th>شناسه حسابداری</th><th>نام در نرم‌افزار حسابداری</th><th>عملیات</th></tr></thead><tbody>';

		foreach ( $rows as $row ) {
			$data = new Accounting_Data( get_post_meta( $row->ID, 'WebPrd', true ) );
			$acc_name = $data->value( 'Name', '' );
			if ( ! is_scalar( $acc_name ) || '' === trim( (string) $acc_name ) ) {
				$acc_name = '—';
			}

			$nonce = wp_create_nonce( 'remove_guid_' . $row->ID );
			$ajax_type = 'product_variation' === $row->post_type ? 'variation' : 'product';
			$edit_link = get_edit_post_link( $row->ID, 'raw' );

			echo '<tr>';
			echo '<td>' . ( $edit_link ? '<a href="' . esc_url( $edit_link ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $row->post_title ) . '</a>' : esc_html( $row->post_title ) ) . '</td>';
			echo '<td>' . esc_html( $row->post_type ) . '</td>';
			echo '<td><code>' . esc_html( $row->guid ) . '</code></td>';
			echo '<td>' . esc_html( $acc_name ) . '</td>';
			echo '<td><a href="#" class="remove-guid" data-id="' . esc_attr( $row->ID ) . '" data-type="' . esc_attr( $ajax_type ) . '" data-nonce="' . esc_attr( $nonce ) . '" style="color:#d63638;text-decoration:none;">قطع ارتباط</a></td>';
			echo '</tr>';
		}

		echo '</tbody></table>';

		$pagination = paginate_links(
			array(
				'total'   => $total_pages,
				'current' => $page,
				'base'    => add_query_arg( 'paged', '%#%' ),
				'format'  => '',
				'type'    => 'plain',
				'prev_text' => 'قبلی',
				'next_text' => 'بعدی',
			)
		);
		if ( $pagination ) {
			echo '<div class="tablenav"><div class="tablenav-pages" style="margin:16px 0;">' . wp_kses_post( $pagination ) . '</div></div>';
		}

		echo '</div>';
		?>
		<script>
		document.addEventListener('DOMContentLoaded', () => {
			document.querySelectorAll('.remove-guid').forEach(link => {
				link.addEventListener('click', e => {
					e.preventDefault();
					if (!confirm('آیا از حذف ارتباط این آیتم اطمینان دارید؟')) return;

					const id = link.dataset.id;
					const type = link.dataset.type || 'product';
					const nonce = link.dataset.nonce;
					link.textContent = 'در حال حذف...';

					fetch(ajaxurl, {
						method: 'POST',
						headers: {'Content-Type': 'application/x-www-form-urlencoded'},
						body: new URLSearchParams({ action: 'remove_guid', id, type, _wpnonce: nonce })
					})
					.then(r => r.json())
					.then(res => {
						if (res.success) {
							link.closest('tr').remove();
						} else {
							alert(res.data?.message || 'خطا در حذف ارتباط');
							link.textContent = 'قطع ارتباط';
						}
					})
					.catch(() => {
						alert('خطا در ارتباط با سرور');
						link.textContent = 'قطع ارتباط';
					});
				});
			});
		});
		</script>
		<?php
	}

	public static function clearCache() {
		delete_transient( self::COUNT_TRANSIENT );
	}
}
}
