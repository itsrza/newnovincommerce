<?php

namespace Novinwp\Novin_Commerce\Common;

use Novinwp\Novin_Commerce\Models\Sync;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Persistent health read model. The dashboard reads aggregates from this table
 * instead of decoding a fixed sample of WebPrd JSON on every request.
 */
final class Health_Snapshot {

	const TABLE_SUFFIX = 'novin_commerce_health_items';
	const CURSOR_OPTION = 'novin_commerce_v2_health_cursor';
	const LAST_BUILD_OPTION = 'novin_commerce_v2_health_last_build';
	const COMPLETE_OPTION   = 'novin_commerce_v2_health_complete';
	private static $table_exists_cache = null;

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . self::TABLE_SUFFIX;
	}

	public static function table_exists() {
		if ( null !== self::$table_exists_cache ) {
			return self::$table_exists_cache;
		}
		global $wpdb;
		$table = self::table();
		self::$table_exists_cache = ( $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) );
		return self::$table_exists_cache;
	}

	public static function upsert_object( $object_id, $object_type = '' ) {
		global $wpdb;
		if ( ! self::table_exists() ) {
			return false;
		}

		$object_id = absint( $object_id );
		$product   = $object_id && function_exists( 'wc_get_product' ) ? wc_get_product( $object_id ) : false;
		if ( ! $product ) {
			return false;
		}

		if ( $product->is_type( 'variation' ) ) {
			$object_type = 'variation';
		} else {
			$object_type = 'product';
		}

		$raw  = get_post_meta( $object_id, 'WebPrd', true );
		$data = new Accounting_Data( $raw );
		$site_guid   = trim( (string) get_post_meta( $object_id, 'guid', true ) );
		$source_guid = $data->source_guid();
		$sync_raw    = trim( (string) get_post_meta( $object_id, '_np-api-sync-date', true ) );
		$sync_time   = Accounting_Data::parse_timestamp( $sync_raw );
		$modified    = $data->modified_timestamp();
		$guid_present = '' !== $site_guid ? 1 : 0;
		$source_guid_present = '' !== $source_guid ? 1 : 0;
		$guid_match   = ( '' !== $source_guid && '' !== $site_guid && 0 === strcasecmp( $source_guid, $site_guid ) ) ? 1 : 0;
		if ( '' === $source_guid && '' === $site_guid ) {
			$guid_match = 0;
		}

		$inventory = $data->inventory_total( Accounting_Data::configured_warehouse_guids() );
		$stale = ( $modified && $sync_time && $modified > ( $sync_time + 1 ) ) ? 1 : 0;
		$mode = self::object_mode( $product, $data );
		$unit_ambiguous = self::multi_unit_is_ambiguous( $product, $data, $mode );
		$levels = 0;
		foreach ( $data->price_levels() as $level ) {
			if ( null !== $level['price'] ) {
				$levels++;
			}
		}
		$mapped_roles = count( $data->mapped_role_prices() );
		$discount_state = $data->discount_state();
		$discount_actionable = 0;
		if ( Accounting_Data::DISCOUNT_EXPIRED === $discount_state || Accounting_Data::DISCOUNT_INVALID === $discount_state ) {
			$discount_actionable = self::has_accounting_owned_sale( $object_id ) ? 1 : 0;
		}

		$stock_known = null !== $inventory ? 1 : 0;
		$webprd_valid = $data->is_valid() ? 1 : 0;
		$sync_unknown = $webprd_valid && ! $sync_time ? 1 : 0;
		$health_status = 'healthy';
		if ( ! $webprd_valid || ( $source_guid_present && ! $guid_present ) || ( $source_guid_present && $guid_present && ! $guid_match ) || $stale || $sync_unknown || ! $stock_known || $unit_ambiguous || $discount_actionable ) {
			$health_status = 'attention';
		}

		$wpdb->replace(
			self::table(),
			array(
				'object_id'             => $object_id,
				'object_type'           => $object_type,
				'guid_present'          => $guid_present,
				'source_guid_present'  => $source_guid_present,
				'guid_match'            => $guid_match,
				'webprd_valid'          => $webprd_valid,
				'stale'                 => $stale,
				'inventory_known'       => $stock_known,
				'inventory_value'       => null === $inventory ? null : $inventory,
				'structure_mode'        => $mode,
				'multi_unit_ambiguous'  => $unit_ambiguous,
				'accounting_price_levels'=> $levels,
				'mapped_roles'           => $mapped_roles,
				'discount_state'        => $discount_state,
				'discount_actionable'    => $discount_actionable,
				'source_modified'        => $modified ? gmdate( 'Y-m-d H:i:s', $modified ) : null,
				'site_sync'              => $sync_time ? gmdate( 'Y-m-d H:i:s', $sync_time ) : null,
				'health_status'          => $health_status,
				'updated_at'             => gmdate( 'Y-m-d H:i:s' ),
			),
			array( '%d', '%s', '%d', '%d', '%d', '%d', '%d', '%d', '%f', '%s', '%d', '%d', '%d', '%s', '%d', '%s', '%s', '%s', '%s' )
		);

		update_option( self::LAST_BUILD_OPTION, time(), false );
		return true;
	}

	public static function remove_object( $object_id, $object_type = '' ) {
		global $wpdb;
		if ( ! self::table_exists() ) {
			return false;
		}
		$object_id = absint( $object_id );
		if ( ! $object_id ) {
			return false;
		}
		if ( '' !== $object_type ) {
			return (bool) $wpdb->delete( self::table(), array( 'object_id' => $object_id, 'object_type' => sanitize_key( $object_type ) ), array( '%d', '%s' ) );
		}
		return (bool) $wpdb->delete( self::table(), array( 'object_id' => $object_id ), array( '%d' ) );
	}

	public static function aggregate() {
		global $wpdb;
		$table = self::table();

		if ( ! self::table_exists() ) {
			return array(
				'source_objects' => 0, 'indexed' => 0, 'complete' => false,
				'healthy' => 0, 'attention' => 0,
				'guid_missing' => 0, 'guid_mismatch' => 0,
				'webprd_invalid' => 0, 'stale' => 0, 'sync_unknown' => 0,
				'inventory_unknown' => 0, 'multi_unit' => 0, 'multi_unit_ambiguous' => 0,
				'composite' => 0, 'variable' => 0, 'price_levels' => 0, 'mapped_roles' => 0,
				'discount_actionable' => 0, 'last_build' => 0, 'cursor' => 0,
			);
		}

		$rows = array();
		$queries = array(
			'source_objects' => "SELECT COUNT(*) FROM {$wpdb->posts} p WHERE p.post_type IN ('product','product_variation') AND p.post_status IN ('publish','private','draft') AND EXISTS (SELECT 1 FROM {$wpdb->postmeta} m WHERE m.post_id=p.ID AND m.meta_key='WebPrd' AND m.meta_value<>'')",
			'indexed' => "SELECT COUNT(*) FROM {$table}",
			'healthy' => "SELECT COUNT(*) FROM {$table} WHERE health_status='healthy'",
			'attention' => "SELECT COUNT(*) FROM {$table} WHERE health_status='attention'",
			'guid_missing' => "SELECT COUNT(*) FROM {$table} WHERE source_guid_present=1 AND guid_present=0",
			'guid_mismatch' => "SELECT COUNT(*) FROM {$table} WHERE source_guid_present=1 AND guid_present=1 AND guid_match=0",
			'webprd_invalid' => "SELECT COUNT(*) FROM {$table} WHERE webprd_valid=0",
			'stale' => "SELECT COUNT(*) FROM {$table} WHERE stale=1",
			'sync_unknown' => "SELECT COUNT(*) FROM {$table} WHERE webprd_valid=1 AND site_sync IS NULL",
			'inventory_unknown' => "SELECT COUNT(*) FROM {$table} WHERE inventory_known=0",
			'multi_unit' => "SELECT COUNT(*) FROM {$table} WHERE structure_mode='multi_unit_variable'",
			'multi_unit_ambiguous' => "SELECT COUNT(*) FROM {$table} WHERE multi_unit_ambiguous=1",
			'composite' => "SELECT COUNT(*) FROM {$table} WHERE structure_mode='composite'",
			'variable' => "SELECT COUNT(*) FROM {$table} WHERE structure_mode='variable'",
			'price_levels' => "SELECT COUNT(*) FROM {$table} WHERE accounting_price_levels>0",
			'discount_actionable' => "SELECT COUNT(*) FROM {$table} WHERE discount_actionable=1",
		);

		foreach ( $queries as $key => $sql ) {
			$rows[ $key ] = (int) $wpdb->get_var( $sql );
		}

		$rows['last_build'] = (int) get_option( self::LAST_BUILD_OPTION, 0 );
		$rows['cursor']     = (int) get_option( self::CURSOR_OPTION, 0 );
		$rows['complete']   = (bool) get_option( self::COMPLETE_OPTION, 0 );
		return $rows;
	}

	public static function recent_attention( $limit = 8 ) {
		global $wpdb;
		if ( ! self::table_exists() ) {
			return array();
		}
		$limit = max( 1, min( 30, (int) $limit ) );
		$sql = $wpdb->prepare(
			"SELECT object_id, object_type, structure_mode, source_guid_present, guid_present, stale, guid_match, inventory_known, multi_unit_ambiguous, discount_actionable, source_modified, site_sync\n			FROM " . self::table() . "\n			WHERE health_status='attention'\n			ORDER BY updated_at DESC, object_id DESC\n			LIMIT %d",
			$limit
		);
		return (array) $wpdb->get_results( $sql );
	}

	public static function backfill_chunk( $limit = 40 ) {
		global $wpdb;
		if ( ! self::table_exists() ) {
			return false;
		}
		$limit = max( 1, min( 100, (int) $limit ) );
		$cursor = (int) get_option( self::CURSOR_OPTION, 0 );
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT p.ID\n				FROM {$wpdb->posts} p\n				WHERE p.ID > %d\n				AND p.post_type IN ('product','product_variation')\n				AND p.post_status IN ('publish','private','draft')\n				AND EXISTS (SELECT 1 FROM {$wpdb->postmeta} m WHERE m.post_id=p.ID AND m.meta_key='WebPrd' AND m.meta_value<>'')\n				ORDER BY p.ID ASC LIMIT %d",
				$cursor,
				$limit
			)
		);

		if ( empty( $ids ) ) {
			update_option( self::CURSOR_OPTION, 0, false );
			update_option( self::COMPLETE_OPTION, 1, false );
			return false;
		}
		update_option( self::COMPLETE_OPTION, 0, false );

		foreach ( $ids as $id ) {
			self::upsert_object( absint( $id ) );
			$cursor = absint( $id );
		}
		update_option( self::CURSOR_OPTION, $cursor, false );
		return true;
	}

	public static function object_mode( \WC_Product $product, Accounting_Data $data ) {
		if ( $data->accounting_nature() === Accounting_Data::MODE_COMPOSITE ) {
			return Accounting_Data::MODE_COMPOSITE;
		}
		if ( $product->is_type( 'variation' ) ) {
			return 'variation';
		}
		if ( $data->is_multi_unit_candidate( $product ) ) {
			return Accounting_Data::MODE_MULTI_UNIT;
		}
		if ( $product->is_type( 'variable' ) ) {
			return Accounting_Data::MODE_VARIABLE;
		}
		if ( $product->is_type( 'simple' ) ) {
			return Accounting_Data::MODE_SIMPLE;
		}
		return Accounting_Data::MODE_UNKNOWN;
	}

	public static function multi_unit_is_ambiguous( \WC_Product $product, Accounting_Data $data, $mode = '' ) {
		if ( Accounting_Data::MODE_MULTI_UNIT !== $mode ) {
			return 0;
		}
		$base_name = Accounting_Data::normalize( $data->base_unit_name() );
		$v2_name   = Accounting_Data::normalize( $data->unit_name_for_guid( $data->v2_guid() ) );
		$v3_name   = Accounting_Data::normalize( $data->unit_name_for_guid( $data->v3_guid() ) );
		if ( empty( $base_name ) ) {
			return 1;
		}
		$children = $product->get_children();
		$required = array();
		foreach ( array( $base_name, $v2_name, $v3_name ) as $name ) {
			if ( '' !== $name ) {
				$required[ $name ] = true;
			}
		}
		if ( empty( $v2_name ) && $data->v2_quantity() > 0 ) {
			return 1;
		}
		if ( empty( $v3_name ) && $data->v3_quantity() > 0 ) {
			return 1;
		}
		$matched = 0;
		foreach ( $children as $child_id ) {
			$variation = wc_get_product( $child_id );
			if ( ! $variation ) {
				continue;
			}
			foreach ( $variation->get_attributes() as $key => $value ) {
				$tax = str_replace( 'attribute_', '', (string) $key );
				$label = wc_attribute_label( $tax );
				$label_key = Accounting_Data::normalize( $label );
				$unit_labels = array( Accounting_Data::normalize( 'واحد' ), Accounting_Data::normalize( 'unit' ), Accounting_Data::normalize( 'units' ) );
				if ( ! in_array( $label_key, $unit_labels, true ) ) {
					continue;
				}
				$value_key = Accounting_Data::normalize( self::readable_attribute( $tax, $value ) );
				if ( isset( $required[ $value_key ] ) ) {
					$matched++;
				}
			}
		}
		return $matched < count( $required ) ? 1 : 0;
	}

	public static function has_accounting_owned_sale( $post_id ) {
		foreach ( NovinCommerce_RolePrice_Roles_Safe::keys() as $role ) {
			if ( 'accounting' === (string) get_post_meta( $post_id, '_novin_sale_origin_' . sanitize_key( $role ), true ) ) {
				return true;
			}
		}
		return false;
	}

	private static function readable_attribute( $taxonomy, $value ) {
		$value = rawurldecode( (string) $value );
		if ( taxonomy_exists( $taxonomy ) ) {
			$term = get_term_by( 'slug', $value, $taxonomy );
			if ( $term && ! is_wp_error( $term ) ) {
				return $term->name;
			}
		}
		return $value;
	}
}

/**
 * Small dependency-safe role key provider for the health layer.
 */
final class NovinCommerce_RolePrice_Roles_Safe {
	public static function keys() {
		if ( class_exists( '\NovinCommerce_RolePrice_Roles' ) ) {
			$roles = array_keys( \NovinCommerce_RolePrice_Roles::get_all_wp_roles() );
			return array_values( array_unique( array_filter( array_map( 'sanitize_key', $roles ) ) ) );
		}
		return array( 'administrator', 'editor', 'author', 'contributor', 'subscriber', 'customer' );
	}
}
