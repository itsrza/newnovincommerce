<?php

namespace Novinwp\Novin_Commerce\Common;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Normalized read model for the WebPrd payload supplied by Novin accounting.
 *
 * Important semantic rules:
 * - Mojodi is a source field, not total warehouse stock.
 * - Stock total comes from valid PrdAnbarRelation[].Amount rows.
 * - Sell1..Sell8 are accounting price levels, not WordPress roles.
 * - Variable products and multi-unit variable products are separate modes.
 * - An accounting discount is active only inside its valid date window.
 */
final class Accounting_Data {

	const MODE_UNKNOWN          = 'unknown';
	const MODE_SIMPLE           = 'simple';
	const MODE_VARIABLE         = 'variable';
	const MODE_MULTI_UNIT       = 'multi_unit_variable';
	const MODE_COMPOSITE        = 'composite';
	const DISCOUNT_NONE         = 'none';
	const DISCOUNT_ACTIVE       = 'active';
	const DISCOUNT_SCHEDULED    = 'scheduled';
	const DISCOUNT_EXPIRED      = 'expired';
	const DISCOUNT_INVALID      = 'invalid';

	private $data = array();
	private $valid = false;
	private $raw_hash = '';

	public function __construct( $raw ) {
		$this->raw_hash = md5( (string) $raw );
		if ( ! is_string( $raw ) || '' === trim( $raw ) || strlen( $raw ) > 750000 ) {
			return;
		}

		$decoded = json_decode( $raw, true, 32 );
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
			$decoded = json_decode( Text_Encoding::normalize( $raw ), true, 32 );
		}
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
			return;
		}

		$this->data  = $decoded;
		$this->valid = true;
	}

	public function is_valid() {
		return $this->valid;
	}

	public function hash() {
		return $this->raw_hash;
	}

	public function all() {
		return $this->data;
	}

	public function value( $key, $default = null ) {
		return array_key_exists( $key, $this->data ) ? $this->data[ $key ] : $default;
	}

	public function source_guid() {
		$guid = $this->value( 'Guid', '' );
		return is_scalar( $guid ) ? trim( (string) $guid ) : '';
	}

	public function modified_raw() {
		$value = $this->value( 'Modified', '' );
		return is_scalar( $value ) ? trim( (string) $value ) : '';
	}

	public function modified_timestamp() {
		return self::parse_timestamp( $this->modified_raw() );
	}

	public function source_stock_indicator() {
		$value = $this->value( 'Mojodi', null );
		return is_numeric( $value ) ? (float) $value : null;
	}

	public function inventory_rows() {
		$rows = $this->value( 'PrdAnbarRelation', array() );
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Calculate stock from valid warehouse relation Amount values.
	 * When no valid relation exists, null is returned, not zero.
	 *
	 * @param array|null $allowed_guids Optional list of warehouse GUIDs.
	 * @return float|null
	 */
	public function inventory_total( $allowed_guids = null ) {
		$rows = $this->inventory_rows();
		if ( empty( $rows ) ) {
			return null;
		}

		$has_valid_amount = false;
		$total             = 0.0;
		$allowed           = array();

		if ( is_array( $allowed_guids ) ) {
			foreach ( $allowed_guids as $guid ) {
				$guid = trim( (string) $guid );
				if ( '' !== $guid ) {
					$allowed[ strtolower( $guid ) ] = true;
				}
			}
		}

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) || ! array_key_exists( 'Amount', $row ) || ! is_numeric( $row['Amount'] ) ) {
				continue;
			}

			if ( ! empty( $allowed ) ) {
				$relation_guid = self::relation_guid( $row );
				if ( '' === $relation_guid || ! isset( $allowed[ strtolower( $relation_guid ) ] ) ) {
					continue;
				}
			}

			$has_valid_amount = true;
			$total            += (float) $row['Amount'];
		}

		return $has_valid_amount ? $total : null;
	}

	public function base_unit_name() {
		$value = $this->value( 'VahedName', '' );
		return is_scalar( $value ) ? trim( (string) $value ) : '';
	}

	public function v2_quantity() {
		$value = $this->value( 'V2Qt', 0 );
		return is_numeric( $value ) && (float) $value > 0 ? (float) $value : 0.0;
	}

	public function v3_quantity() {
		$value = $this->value( 'V3Qt', 0 );
		return is_numeric( $value ) && (float) $value > 0 ? (float) $value : 0.0;
	}

	public function v2_guid() {
		$value = $this->value( 'V2Guid', '' );
		return is_scalar( $value ) ? trim( (string) $value ) : '';
	}

	public function v3_guid() {
		$value = $this->value( 'V3Guid', '' );
		return is_scalar( $value ) ? trim( (string) $value ) : '';
	}

	public function base_unit_guid() {
		$value = $this->value( 'GuidVahed', '' );
		return is_scalar( $value ) ? trim( (string) $value ) : '';
	}

	public function has_unit_data() {
		return $this->v2_quantity() > 0 || $this->v3_quantity() > 0;
	}

	/**
	 * Determine product nature independently of WooCommerce product type.
	 */
	public function accounting_nature() {
		$kind      = $this->value( 'Kind', null );
		$formula   = trim( (string) $this->value( 'TolidFormulaGuid', '' ) );
		$production = $this->value( 'ProductionCapacity', null );

		if ( '' !== $formula || 2 === (int) $kind ) {
			return self::MODE_COMPOSITE;
		}

		if ( null !== $production && is_numeric( $production ) && (float) $production > 0 && 2 === (int) $kind ) {
			return self::MODE_COMPOSITE;
		}

		return self::MODE_UNKNOWN;
	}

	/**
	 * Multi-unit is explicit only when accounting exposes unit conversion data
	 * and the WooCommerce product uses a unit-like attribute. The class itself
	 * does not assume every variable product is multi-unit.
	 */
	public function is_multi_unit_candidate( \WC_Product $product ) {
		if ( ! $product->is_type( 'variable' ) || ! $this->has_unit_data() ) {
			return false;
		}

		$allowed_names = apply_filters(
			'novin_commerce_multi_unit_attribute_names',
			array( 'واحد', 'unit', 'units' )
		);

		$allowed = array();
		foreach ( (array) $allowed_names as $name ) {
			$key = self::normalize( $name );
			if ( '' !== $key ) {
				$allowed[ $key ] = true;
			}
		}

		foreach ( $product->get_attributes() as $attribute_key => $attribute ) {
			$label = '';
			if ( is_object( $attribute ) && is_callable( array( $attribute, 'get_name' ) ) ) {
				$label = wc_attribute_label( $attribute->get_name() );
			} else {
				$label = wc_attribute_label( str_replace( 'attribute_', '', (string) $attribute_key ) );
			}
			if ( isset( $allowed[ self::normalize( $label ) ] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Return the accounting price levels. Never map levels to roles by array
	 * position. The optional Prices[] rows are matched by exact price value
	 * only, never by their order in the array.
	 */
	public function price_levels() {
		$prices = $this->value( 'Prices', array() );
		$prices = is_array( $prices ) ? $prices : array();
		$result = array();

		for ( $i = 1; $i <= 8; $i++ ) {
			$key   = 'Sell' . $i;
			$value = $this->value( $key, null );
			$level = array(
				'level'       => $i,
				'key'         => $key,
				'price'       => is_numeric( $value ) && (float) $value > 0 ? (float) $value : null,
				'guid'        => '',
				'mapping'     => 'unknown',
			);

			if ( null !== $level['price'] ) {
				$matched_guids = array();
				foreach ( $prices as $price_row ) {
					if ( ! is_array( $price_row ) || ! isset( $price_row['Price'] ) || ! is_numeric( $price_row['Price'] ) ) {
						continue;
					}
					if ( abs( (float) $price_row['Price'] - $level['price'] ) > 0.000001 ) {
						continue;
					}
					$guid = isset( $price_row['PriceLevelGuid'] ) ? trim( (string) $price_row['PriceLevelGuid'] ) : '';
					if ( '' !== $guid ) {
						$matched_guids[] = $guid;
					}
				}
				$matched_guids = array_values( array_unique( $matched_guids ) );
				if ( 1 === count( $matched_guids ) ) {
					$level['guid']    = $matched_guids[0];
					$level['mapping'] = 'price_match';
				} elseif ( count( $matched_guids ) > 1 ) {
					$level['mapping'] = 'ambiguous';
				}
			}

			$result[] = $level;
		}

		return $result;
	}

	/**
	 * Explicit WordPress role mappings only. Empty Price entries do not erase
	 * local/manual values.
	 */
	public function role_price_rows() {
		$rows = $this->value( 'PriceRoleList', array() );
		return is_array( $rows ) ? $rows : array();
	}

	public function mapped_role_prices() {
		$result = array();
		foreach ( $this->role_price_rows() as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$name = isset( $row['WordPressRoleName'] ) ? trim( (string) $row['WordPressRoleName'] ) : '';
			$price = isset( $row['Price'] ) && is_numeric( $row['Price'] ) && (float) $row['Price'] > 0 ? (float) $row['Price'] : null;
			if ( '' === $name || null === $price ) {
				continue;
			}
			$result[] = array(
				'name'  => $name,
				'price' => $price,
			);
		}
		return $result;
	}

	public function discount_percent() {
		$value = $this->value( 'DiscountPercent', 0 );
		if ( ! is_numeric( $value ) ) {
			return 0.0;
		}
		return max( 0.0, min( 100.0, (float) $value ) );
	}

	public function discount_start_timestamp() {
		return self::parse_timestamp( $this->value( 'DiscountStartDate', '' ) );
	}

	public function discount_end_timestamp() {
		return self::parse_timestamp( $this->value( 'DiscountEndDate', '' ) );
	}

	public function discount_state( $now = null ) {
		$percent = $this->discount_percent();
		if ( $percent <= 0 ) {
			return self::DISCOUNT_NONE;
		}

		$now   = null === $now ? time() : (int) $now;
		$start = $this->discount_start_timestamp();
		$end   = $this->discount_end_timestamp();

		if ( ! $start && ! $end ) {
			return self::DISCOUNT_INVALID;
		}
		if ( $start && $now < $start ) {
			return self::DISCOUNT_SCHEDULED;
		}
		if ( $end && $now > $end ) {
			return self::DISCOUNT_EXPIRED;
		}
		return self::DISCOUNT_ACTIVE;
	}

	public function discount_sale_price( $regular_price ) {
		$regular_price = is_numeric( $regular_price ) ? (float) $regular_price : 0.0;
		$percent       = $this->discount_percent();
		if ( $regular_price <= 0 || $percent <= 0 || self::DISCOUNT_ACTIVE !== $this->discount_state() ) {
			return null;
		}
		return round( $regular_price * ( 1 - ( $percent / 100 ) ), wc_get_price_decimals() );
	}

	public function unit_name_for_guid( $guid ) {
		$guid = trim( (string) $guid );
		if ( '' === $guid ) {
			return '';
		}
		$found = self::find_label_by_guid( $this->data, $guid );
		return $found;
	}

	public function normalized() {
		return array(
			'guid'              => $this->source_guid(),
			'modified'          => $this->modified_timestamp(),
			'mojodi'            => $this->source_stock_indicator(),
			'inventory'         => $this->inventory_total( self::configured_warehouse_guids() ),
			'base_unit_name'    => $this->base_unit_name(),
			'v2_qty'            => $this->v2_quantity(),
			'v3_qty'            => $this->v3_quantity(),
			'v2_guid'           => $this->v2_guid(),
			'v3_guid'           => $this->v3_guid(),
			'base_unit_guid'    => $this->base_unit_guid(),
			'discount_percent'  => $this->discount_percent(),
			'discount_state'    => $this->discount_state(),
			'price_levels'      => $this->price_levels(),
		);
	}

	public static function from_post( $post_id ) {
		$raw = get_post_meta( absint( $post_id ), 'WebPrd', true );
		return new self( $raw );
	}

	public static function configured_warehouse_guids() {
		$value = get_option( 'novin_commerce_inventory_warehouse_guids', array() );
		if ( ! is_array( $value ) ) {
			return array();
		}
		return array_values( array_filter( array_map( 'sanitize_text_field', $value ) ) );
	}

	public static function normalize( $value ) {
		if ( ! is_string( $value ) ) {
			return '';
		}
		$value = rawurldecode( trim( $value ) );
		$value = str_replace( array( ' ', "\xC2\xA0", "\xE2\x80\x8C" ), '', $value );
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $value, 'UTF-8' ) : strtolower( $value );
	}

	public static function parse_timestamp( $value ) {
		if ( ! is_scalar( $value ) ) {
			return 0;
		}
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return 0;
		}

		$timestamp = strtotime( str_replace( '/', '-', $value ) );
		return false === $timestamp ? 0 : (int) $timestamp;
	}

	private static function relation_guid( array $row ) {
		foreach ( array( 'GuidAnbar', 'AnbarGuid', 'GuidWarehouse', 'WarehouseGuid', 'Guid', 'IdGuid' ) as $key ) {
			if ( isset( $row[ $key ] ) && is_scalar( $row[ $key ] ) && '' !== trim( (string) $row[ $key ] ) ) {
				return trim( (string) $row[ $key ] );
			}
		}
		return '';
	}

	private static function find_label_by_guid( $node, $guid ) {
		if ( ! is_array( $node ) ) {
			return '';
		}

		foreach ( $node as $key => $value ) {
			if ( is_array( $value ) ) {
				$found = self::find_label_by_guid( $value, $guid );
				if ( '' !== $found ) {
					return $found;
				}
			}
		}

		$node_guid = '';
		foreach ( array( 'Guid', 'guid', 'GUID', 'UnitGuid', 'ValueGuid', 'IdGuid' ) as $key ) {
			if ( isset( $node[ $key ] ) && is_scalar( $node[ $key ] ) ) {
				$node_guid = trim( (string) $node[ $key ] );
				if ( $node_guid === $guid ) {
					break;
				}
			}
		}

		if ( $node_guid !== $guid ) {
			return '';
		}

		foreach ( array( 'Name', 'name', 'ValueName', 'UnitName', 'Caption', 'Title', 'Text', 'Value' ) as $key ) {
			if ( isset( $node[ $key ] ) && is_scalar( $node[ $key ] ) ) {
				$value = trim( (string) $node[ $key ] );
				if ( '' !== $value ) {
					return $value;
				}
			}
		}

		return '';
	}
}
