<?php

use Novinwp\Novin_Commerce\Common\Accounting_Data;
use Novinwp\Novin_Commerce\Common\Health_Snapshot;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Multi-unit stock engine.
 *
 * This class is intentionally isolated from normal Variable Products.
 * It activates only when WebPrd exposes V2/V3 conversion data and the
 * WooCommerce product uses an explicit unit attribute.
 */
class NovinCommerce_RolePrice_Multi_Unit_Stock {

	const META_BASE_STOCK     = '_wcpbr_base_stock';
	const META_UNITS_PER_PACK = '_wcpbr_units_per_pack';
	const META_IS_BASE_UNIT   = '_wcpbr_is_base_unit';
	const META_SYNC_MARKER    = '_wcpbr_units_sync_hash';
	const META_MODE           = '_novin_product_structure_mode';
	private static $instance = null;

	public function __construct() {
		self::$instance = $this;
		add_filter( 'woocommerce_add_to_cart_validation', array( $this, 'validate_add_to_cart' ), 1000, 4 );
		add_filter( 'woocommerce_variation_is_visible', array( $this, 'hide_outofstock_variation' ), 1000, 4 );
		add_filter( 'woocommerce_dropdown_variation_attribute_options_args', array( $this, 'filter_dropdown_options' ), 1000, 1 );
		add_filter( 'woocommerce_get_available_variations', array( $this, 'remove_outofstock_from_available' ), 1000, 3 );
		add_action( 'woocommerce_reduce_order_stock', array( $this, 'reduce_base_stock_on_order' ), 20, 1 );
		add_action( 'woocommerce_restore_order_stock', array( $this, 'restore_base_stock_on_order' ), 20, 1 );
	}

	public static function sync_product_static( $product_id ) {
		$instance = self::$instance;
		if ( ! $instance ) {
			$instance = new self();
		}
		$instance->sync_product_units( $product_id );
	}

	public function sync_product_units( $product_id ) {
		$product_id = absint( $product_id );
		$product    = $product_id ? wc_get_product( $product_id ) : false;
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			return false;
		}

		$data = new Accounting_Data( get_post_meta( $product_id, 'WebPrd', true ) );
		if ( ! $data->is_valid() || ! $data->is_multi_unit_candidate( $product ) ) {
			delete_post_meta( $product_id, self::META_MODE );
			return false;
		}

		$base_stock = $data->inventory_total( Accounting_Data::configured_warehouse_guids() );
		$mapping = $this->build_variation_mapping( $product, $data );
		update_post_meta( $product_id, self::META_BASE_STOCK, null === $base_stock ? '' : wc_format_decimal( $base_stock ) );
		update_post_meta( $product_id, self::META_MODE, Accounting_Data::MODE_MULTI_UNIT );

		if ( $mapping['ambiguous'] ) {
			Health_Snapshot::upsert_object( $product_id );
			return false;
		}

		if ( null === $base_stock ) {
			Health_Snapshot::upsert_object( $product_id );
			return false;
		}

		foreach ( $mapping['items'] as $variation_id => $units ) {
			$variation = wc_get_product( $variation_id );
			if ( ! $variation ) {
				continue;
			}
			update_post_meta( $variation_id, self::META_UNITS_PER_PACK, (string) $units );
			update_post_meta( $variation_id, self::META_IS_BASE_UNIT, 1 === (int) $units ? '1' : '0' );
			update_post_meta( $variation_id, self::META_SYNC_MARKER, md5( $data->hash() . '|' . $variation_id . '|' . $units ) );
			$this->apply_stock_to_variation( $variation, $base_stock, $units );
		}

		$this->make_parent_aggregate_only( $product );
		wc_delete_product_transients( $product_id );
		Health_Snapshot::upsert_object( $product_id );
		return true;
	}

	private function build_variation_mapping( WC_Product $product, Accounting_Data $data ) {
		$base_name = Accounting_Data::normalize( $data->base_unit_name() );
		$v2_name   = Accounting_Data::normalize( $data->unit_name_for_guid( $data->v2_guid() ) );
		$v3_name   = Accounting_Data::normalize( $data->unit_name_for_guid( $data->v3_guid() ) );
		$v2_qty    = $data->v2_quantity();
		$v3_qty    = $data->v3_quantity();

		$required = array();
		if ( '' === $base_name ) {
			return array( 'ambiguous' => true, 'items' => array() );
		}
		$required[ $base_name ] = 1.0;
		if ( $v2_qty > 0 ) {
			if ( '' === $v2_name || ( isset( $required[ $v2_name ] ) && abs( $required[ $v2_name ] - $v2_qty ) > 0.000001 ) ) {
				return array( 'ambiguous' => true, 'items' => array() );
			}
			$required[ $v2_name ] = $v2_qty;
		}
		if ( $v3_qty > 0 ) {
			if ( '' === $v3_name || ( isset( $required[ $v3_name ] ) && abs( $required[ $v3_name ] - $v3_qty ) > 0.000001 ) ) {
				return array( 'ambiguous' => true, 'items' => array() );
			}
			$required[ $v3_name ] = $v3_qty;
		}
		if ( '' !== $v2_name && '' !== $v3_name && $v2_name === $v3_name && $data->v2_guid() !== $data->v3_guid() ) {
			return array( 'ambiguous' => true, 'items' => array() );
		}

		$items = array();
		foreach ( $product->get_children() as $variation_id ) {
			$variation = wc_get_product( $variation_id );
			if ( ! $variation ) {
				continue;
			}
			$value = $this->get_unit_attribute_value( $variation );
			if ( '' === $value ) {
				return array( 'ambiguous' => true, 'items' => array() );
			}
			$value_key = Accounting_Data::normalize( $value );
			if ( ! isset( $required[ $value_key ] ) ) {
				return array( 'ambiguous' => true, 'items' => array() );
			}
			if ( isset( $items[ $variation_id ] ) ) {
				return array( 'ambiguous' => true, 'items' => array() );
			}
			$items[ $variation_id ] = $required[ $value_key ];
		}

		foreach ( $required as $required_name => $units ) {
			$found = false;
			foreach ( $items as $mapped_units ) {
				if ( abs( $mapped_units - $units ) < 0.000001 ) {
					$found = true;
					break;
				}
			}
			if ( ! $found ) {
				return array( 'ambiguous' => true, 'items' => array() );
			}
		}

		return array( 'ambiguous' => false, 'items' => $items );
	}

	private function get_unit_attribute_value( WC_Product $variation ) {
		foreach ( $variation->get_attributes() as $attribute_key => $attribute_value ) {
			$taxonomy = str_replace( 'attribute_', '', (string) $attribute_key );
			$label    = wc_attribute_label( $taxonomy );
			if ( 'واحد' !== $label && 'unit' !== strtolower( (string) $label ) && 'units' !== strtolower( (string) $label ) ) {
				continue;
			}
			$value = rawurldecode( (string) $attribute_value );
			if ( taxonomy_exists( $taxonomy ) ) {
				$term = get_term_by( 'slug', $value, $taxonomy );
				if ( $term && ! is_wp_error( $term ) ) {
					return $term->name;
				}
			}
			return $value;
		}
		return '';
	}

	private function make_parent_aggregate_only( WC_Product $product ) {
		$changed = false;
		if ( $product->get_manage_stock() ) {
			$product->set_manage_stock( false );
			$changed = true;
		}
		if ( null !== $product->get_stock_quantity() ) {
			$product->set_stock_quantity( null );
			$changed = true;
		}
		$has_stock = false;
		foreach ( $product->get_children() as $variation_id ) {
			$variation = wc_get_product( $variation_id );
			if ( $variation && $variation->is_in_stock() ) {
				$has_stock = true;
				break;
			}
		}
		$status = $has_stock ? 'instock' : 'outofstock';
		if ( $product->get_stock_status() !== $status ) {
			$product->set_stock_status( $status );
			$changed = true;
		}
		if ( $changed ) {
			$product->save();
		}
	}

	private function apply_stock_to_variation( WC_Product $variation, $base_stock, $units_per_pack ) {
		$units_per_pack = max( 1.0, (float) $units_per_pack );
		$stock = floor( max( 0.0, (float) $base_stock ) / $units_per_pack );
		$status = $stock > 0 ? 'instock' : 'outofstock';
		$changed = false;
		if ( ! $variation->get_manage_stock() ) {
			$variation->set_manage_stock( true );
			$changed = true;
		}
		if ( (float) $variation->get_stock_quantity() !== (float) $stock ) {
			$variation->set_stock_quantity( $stock );
			$changed = true;
		}
		if ( $variation->get_stock_status() !== $status ) {
			$variation->set_stock_status( $status );
			$changed = true;
		}
		if ( $changed ) {
			$variation->save();
		}
	}

	private function is_multi_unit_parent( $product_id ) {
		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			return false;
		}
		$data = new Accounting_Data( get_post_meta( $product_id, 'WebPrd', true ) );
		return $data->is_valid() && $data->is_multi_unit_candidate( $product );
	}

	private function is_managed_variation( $variation_id ) {
		$variation_id = absint( $variation_id );
		if ( ! $variation_id ) {
			return false;
		}
		$parent_id = wp_get_post_parent_id( $variation_id );
		return $parent_id && $this->is_multi_unit_parent( $parent_id ) && '' !== (string) get_post_meta( $variation_id, self::META_UNITS_PER_PACK, true );
	}

	public function hide_outofstock_variation( $visible, $variation_id, $parent_id, $variation = null ) {
		if ( ! $parent_id || ! $this->is_multi_unit_parent( $parent_id ) || ! $this->is_managed_variation( $variation_id ) ) {
			return $visible;
		}
		$variation = $variation instanceof WC_Product ? $variation : wc_get_product( $variation_id );
		if ( ! $variation ) {
			return $visible;
		}
		return $variation->is_in_stock() && (int) $variation->get_stock_quantity() > 0;
	}

	public function filter_dropdown_options( $args ) {
		$product = isset( $args['product'] ) && $args['product'] instanceof WC_Product ? $args['product'] : false;
		if ( ! $product || ! $product->is_type( 'variable' ) || ! $this->is_multi_unit_parent( $product->get_id() ) ) {
			return $args;
		}
		$options = isset( $args['options'] ) && is_array( $args['options'] ) ? $args['options'] : array();
		if ( empty( $options ) ) {
			return $args;
		}
		$attribute = isset( $args['attribute'] ) ? (string) $args['attribute'] : '';
		if ( '' === $attribute ) {
			return $args;
		}
		$available = array();
		foreach ( $options as $option ) {
			if ( $this->option_has_instock_variation( $product, $attribute, $option ) ) {
				$available[] = $option;
			}
		}
		$args['options'] = $available;
		return $args;
	}

	private function option_has_instock_variation( WC_Product $product, $attribute, $option ) {
		$option = Accounting_Data::normalize( rawurldecode( (string) $option ) );
		foreach ( $product->get_children() as $variation_id ) {
			$variation = wc_get_product( $variation_id );
			if ( ! $variation || ! $this->is_managed_variation( $variation_id ) ) {
				continue;
			}
			foreach ( $variation->get_attributes() as $key => $value ) {
				if ( (string) $key !== $attribute ) {
					continue;
				}
				$value = Accounting_Data::normalize( rawurldecode( (string) $value ) );
				if ( $value === $option && $variation->is_in_stock() && (int) $variation->get_stock_quantity() > 0 ) {
					return true;
				}
			}
		}
		return false;
	}

	public function remove_outofstock_from_available( $available, $product, $parent = null ) {
		$parent_obj = $parent instanceof WC_Product ? $parent : $product;
		if ( ! is_array( $available ) || ! $parent_obj instanceof WC_Product || ! $parent_obj->is_type( 'variable' ) || ! $this->is_multi_unit_parent( $parent_obj->get_id() ) ) {
			return $available;
		}
		$filtered = array();
		foreach ( $available as $item ) {
			$variation_id = ! empty( $item['variation_id'] ) ? absint( $item['variation_id'] ) : 0;
			if ( ! $variation_id || ! $this->is_managed_variation( $variation_id ) ) {
				$filtered[] = $item;
				continue;
			}
			$variation = wc_get_product( $variation_id );
			if ( $variation && $variation->is_in_stock() && (int) $variation->get_stock_quantity() > 0 ) {
				$filtered[] = $item;
			}
		}
		return array_values( $filtered );
	}

	public function validate_add_to_cart( $passed, $product_id, $quantity, $variation_id = 0 ) {
		$variation_id = absint( $variation_id );
		if ( ! $variation_id || ! $this->is_managed_variation( $variation_id ) ) {
			return $passed;
		}
		$variation = wc_get_product( $variation_id );
		if ( ! $variation ) {
			return $passed;
		}
		$stock = (int) $variation->get_stock_quantity();
		if ( ! $variation->is_in_stock() || $stock < 1 ) {
			wc_add_notice( esc_html__( 'این واحد در حال حاضر موجود نیست.', 'novin-commerce' ), 'error' );
			return false;
		}
		if ( (int) $quantity > $stock ) {
			wc_add_notice( sprintf( esc_html__( 'حداکثر تعداد قابل خرید در این واحد: %d', 'novin-commerce' ), $stock ), 'error' );
			return false;
		}
		return $passed;
	}

	public function reduce_base_stock_on_order( $order ) {
		if ( ! $order instanceof WC_Order ) {
			return;
		}
		foreach ( $order->get_items() as $item_id => $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) {
				continue;
			}
			$variation_id = absint( $item->get_variation_id() );
			if ( ! $variation_id || ! $this->is_managed_variation( $variation_id ) ) {
				continue;
			}
			if ( 'yes' === (string) $item->get_meta( '_novin_multi_unit_stock_reduced', true ) ) {
				continue;
			}
			$parent_id = absint( $item->get_product_id() );
			$units     = max( 1.0, (float) get_post_meta( $variation_id, self::META_UNITS_PER_PACK, true ) );
			$qty       = max( 0, (float) $item->get_quantity() );
			if ( ! $parent_id || $qty <= 0 ) {
				continue;
			}
			$base = (float) get_post_meta( $parent_id, self::META_BASE_STOCK, true );
			$reduction = $qty * $units;
			$new_base = max( 0, $base - $reduction );
			update_post_meta( $parent_id, self::META_BASE_STOCK, $new_base );
			$item->update_meta_data( '_novin_multi_unit_stock_reduced', 'yes' );
			$item->update_meta_data( '_novin_multi_unit_stock_delta', (string) $reduction );
			$item->save();
			$this->rebalance_variations( $parent_id );
		}
	}

	public function restore_base_stock_on_order( $order ) {
		if ( ! $order instanceof WC_Order ) {
			return;
		}
		foreach ( $order->get_items() as $item ) {
			if ( ! $item instanceof WC_Order_Item_Product || 'yes' !== (string) $item->get_meta( '_novin_multi_unit_stock_reduced', true ) ) {
				continue;
			}
			$parent_id = absint( $item->get_product_id() );
			$delta     = (float) $item->get_meta( '_novin_multi_unit_stock_delta', true );
			if ( ! $parent_id || $delta <= 0 ) {
				continue;
			}
			$base = (float) get_post_meta( $parent_id, self::META_BASE_STOCK, true );
			update_post_meta( $parent_id, self::META_BASE_STOCK, $base + $delta );
			$item->delete_meta_data( '_novin_multi_unit_stock_reduced' );
			$item->delete_meta_data( '_novin_multi_unit_stock_delta' );
			$item->save();
			$this->rebalance_variations( $parent_id );
		}
	}

	private function rebalance_variations( $product_id ) {
		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			return;
		}
		$base_stock = (float) get_post_meta( $product_id, self::META_BASE_STOCK, true );
		foreach ( $product->get_children() as $variation_id ) {
			if ( '' === (string) get_post_meta( $variation_id, self::META_UNITS_PER_PACK, true ) ) {
				continue;
			}
			$variation = wc_get_product( $variation_id );
			if ( ! $variation ) {
				continue;
			}
			$units = max( 1.0, (float) get_post_meta( $variation_id, self::META_UNITS_PER_PACK, true ) );
			$this->apply_stock_to_variation( $variation, $base_stock, $units );
		}
		$this->make_parent_aggregate_only( $product );
	}
}
