<?php

use Novinwp\Novin_Commerce\Common\Accounting_Data;
use Novinwp\Novin_Commerce\Common\Health_Snapshot;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Synchronizes accounting-owned product state.
 *
 * v2.0 rules:
 * - No synchronization is triggered during front-end product rendering.
 * - WebPrd is the source for accounting data; Mojodi is never treated as
 *   total warehouse stock.
 * - PriceRoleList is an explicit role mapping. Sell1..Sell8 remain separate
 *   accounting price levels.
 * - Accounting-owned expired discounts are removed, while manual discounts
 *   are preserved.
 */
class NovinCommerce_RolePrice_Accounting_Sync {

	const SYNC_MARKER_META = '_wcpbr_last_synced_np_date';
	const ORIGIN_ACCOUNTING = 'accounting';
	const ORIGIN_MANUAL     = 'manual';
	const ORIGIN_LEGACY     = 'legacy';
	const ORIGIN_UNKNOWN    = 'unknown';

	private static $syncing = array();
	private static $instance = null;

	public function __construct() {
		self::$instance = $this;
		add_action( 'added_post_meta', array( $this, 'maybe_sync_meta' ), 20, 4 );
		add_action( 'updated_post_meta', array( $this, 'maybe_sync_meta' ), 20, 4 );
		add_action( 'deleted_post_meta', array( $this, 'maybe_sync_deleted_meta' ), 20, 4 );
		add_action( 'before_delete_post', array( $this, 'cleanup_deleted_object' ), 20, 1 );
	}

	public static function get_instance() {
		return self::$instance;
	}

	public static function is_syncing( $post_id = 0 ) {
		if ( ! $post_id ) {
			return ! empty( self::$syncing );
		}
		return ! empty( self::$syncing[ absint( $post_id ) ] );
	}

	public function maybe_sync_meta( $meta_id, $post_id, $meta_key, $meta_value ) {
		unset( $meta_id, $meta_value );
		if ( ! in_array( $meta_key, array( 'WebPrd', '_np-api-sync-date', 'guid' ), true ) ) {
			return;
		}
		$this->sync_product( $post_id );
	}

	public function maybe_sync_deleted_meta( $meta_ids, $post_id, $meta_key, $meta_value ) {
		unset( $meta_ids, $meta_value );
		if ( 'WebPrd' === $meta_key ) {
			Health_Snapshot::remove_object( $post_id );
			return;
		}
		if ( in_array( $meta_key, array( '_np-api-sync-date', 'guid' ), true ) ) {
			Health_Snapshot::upsert_object( $post_id );
		}
	}

	public function cleanup_deleted_object( $post_id ) {
		$post_id = absint( $post_id );
		if ( ! $post_id ) {
			return;
		}
		$post_type = get_post_type( $post_id );
		if ( ! in_array( $post_type, array( 'product', 'product_variation' ), true ) ) {
			return;
		}
		Health_Snapshot::remove_object( $post_id );
		if ( 'product' === $post_type ) {
			foreach ( get_children( array( 'post_parent' => $post_id, 'post_type' => 'product_variation', 'fields' => 'ids' ) ) as $variation_id ) {
				Health_Snapshot::remove_object( absint( $variation_id ) );
			}
		}
	}

	public function maybe_sync_on_product_save( $post_id, $post, $update ) {
		unset( $post, $update );
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}
		if ( get_post_meta( $post_id, 'WebPrd', true ) ) {
			$this->sync_product( $post_id );
		}
	}

	public function maybe_sync_on_variation_save( $post_id, $post, $update ) {
		unset( $post, $update );
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		$parent_id = wp_get_post_parent_id( $post_id );
		if ( $parent_id && get_post_meta( $parent_id, 'WebPrd', true ) ) {
			$this->sync_product( $parent_id );
		}
		if ( get_post_meta( $post_id, 'WebPrd', true ) ) {
			$this->sync_product( $post_id );
		}
	}

	public function sync_product( $product_id ) {
		$product_id = absint( $product_id );
		if ( ! $product_id || self::is_syncing( $product_id ) || ! function_exists( 'wc_get_product' ) ) {
			return false;
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return false;
		}

		if ( $product->is_type( 'variation' ) ) {
			$parent_id = $product->get_parent_id();
			if ( $parent_id ) {
				$this->sync_parent_pricing_and_structure( $parent_id );
			}
			$this->sync_single_object( $product );
			return true;
		}

		$this->sync_parent_pricing_and_structure( $product_id );
		return true;
	}

	private function sync_parent_pricing_and_structure( $product_id ) {
		$product_id = absint( $product_id );
		$product    = wc_get_product( $product_id );
		if ( ! $product ) {
			return;
		}
		$this->sync_single_object( $product );

		if ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_children() as $variation_id ) {
				$variation = wc_get_product( $variation_id );
				if ( ! $variation ) {
					continue;
				}
				$this->sync_single_variation_state( $product, $variation );
			}
			if ( class_exists( 'NovinCommerce_RolePrice_Multi_Unit_Stock' ) ) {
				NovinCommerce_RolePrice_Multi_Unit_Stock::sync_product_static( $product_id );
			}
		}
	}

	private function sync_single_object( $product ) {
		$product_id = absint( $product->get_id() );
		if ( ! $product_id || self::is_syncing( $product_id ) ) {
			return;
		}

		self::$syncing[ $product_id ] = true;
		try {
			$webprd_raw = get_post_meta( $product_id, 'WebPrd', true );
			$data       = new Accounting_Data( $webprd_raw );

			if ( $data->is_valid() ) {
				$mode = Health_Snapshot::object_mode( $product, $data );
				update_post_meta( $product_id, '_novin_product_structure_mode', $mode );
				$this->ensure_guid( $product_id, $data );
				$this->sync_prices( $product_id, $data );
				$this->sync_discount( $product_id, $data );
				$this->sync_accounting_levels( $product_id, $data );
				$this->sync_standard_inventory( $product, $data );
				$this->update_sync_marker( $product_id );
			}

			Health_Snapshot::upsert_object( $product_id );
			if ( function_exists( 'wc_delete_product_transients' ) ) {
				wc_delete_product_transients( $product_id );
			}
		} finally {
			unset( self::$syncing[ $product_id ] );
		}
	}

	private function sync_single_variation_state( $parent, $variation ) {
		$parent_id    = absint( $parent->get_id() );
		$variation_id = absint( $variation->get_id() );
		if ( ! $variation_id || self::is_syncing( $variation_id ) ) {
			return;
		}

		// A normal variable product owns stock at variation level. The parent is
		// a container/aggregate and must not hold a separate zero stock.
		$parent_data = new Accounting_Data( get_post_meta( $parent_id, 'WebPrd', true ) );
		$parent_mode = Health_Snapshot::object_mode( $parent, $parent_data );
		if ( Accounting_Data::MODE_MULTI_UNIT === $parent_mode ) {
			return;
		}

		$variation_data = new Accounting_Data( get_post_meta( $variation_id, 'WebPrd', true ) );
		if ( ! $variation_data->is_valid() ) {
			return;
		}

		self::$syncing[ $variation_id ] = true;
		try {
			update_post_meta( $variation_id, '_novin_product_structure_mode', 'variation' );
			$this->ensure_guid( $variation_id, $variation_data );
			$this->sync_prices( $variation_id, $variation_data );
			$this->sync_discount( $variation_id, $variation_data );
			$this->sync_accounting_levels( $variation_id, $variation_data );

			$inventory = $variation_data->inventory_total( Accounting_Data::configured_warehouse_guids() );
			if ( null !== $inventory ) {
				$this->apply_inventory( $variation, $inventory );
			}
			$this->update_sync_marker( $variation_id );
			Health_Snapshot::upsert_object( $variation_id );
		} finally {
			unset( self::$syncing[ $variation_id ] );
		}
	}

	private function sync_standard_inventory( $product, Accounting_Data $data ) {
		if ( $product->is_type( 'variable' ) ) {
			// Parent stock is never treated as the stock of all variations.
			if ( ! $data->is_multi_unit_candidate( $product ) ) {
				$this->make_variable_parent_aggregate_only( $product );
			}
			return;
		}

		$inventory = $data->inventory_total( Accounting_Data::configured_warehouse_guids() );
		if ( null !== $inventory ) {
			$this->apply_inventory( $product, $inventory );
		}
	}

	private function make_variable_parent_aggregate_only( $product ) {
		$changed = false;
		if ( $product->get_manage_stock() ) {
			$product->set_manage_stock( false );
			$changed = true;
		}
		if ( null !== $product->get_stock_quantity() ) {
			$product->set_stock_quantity( null );
			$changed = true;
		}

		$children = $product->get_children();
		$has_stock = false;
		foreach ( $children as $child_id ) {
			$child = wc_get_product( $child_id );
			if ( $child && $child->is_in_stock() ) {
				$has_stock = true;
				break;
			}
		}
		$new_status = $has_stock ? 'instock' : 'outofstock';
		if ( $product->get_stock_status() !== $new_status ) {
			$product->set_stock_status( $new_status );
			$changed = true;
		}
		if ( $changed ) {
			self::$syncing[ $product->get_id() ] = true;
			try {
				$product->save();
			} finally {
				unset( self::$syncing[ $product->get_id() ] );
			}
		}
	}

	private function apply_inventory( $product, $inventory ) {
		$inventory = max( 0, (float) $inventory );
		$changed   = false;
		if ( ! $product->get_manage_stock() ) {
			$product->set_manage_stock( true );
			$changed = true;
		}
		if ( ( null === $product->get_stock_quantity() ? null : (float) $product->get_stock_quantity() ) !== $inventory ) {
			$product->set_stock_quantity( $inventory );
			$changed = true;
		}
		$new_status = $inventory > 0 ? 'instock' : 'outofstock';
		if ( $product->get_stock_status() !== $new_status ) {
			$product->set_stock_status( $new_status );
			$changed = true;
		}
		if ( $changed ) {
			$id = absint( $product->get_id() );
			self::$syncing[ $id ] = true;
			try {
				$product->save();
			} finally {
				unset( self::$syncing[ $id ] );
			}
		}
	}

	private function ensure_guid( $post_id, Accounting_Data $data ) {
		$source_guid = $data->source_guid();
		if ( '' === $source_guid ) {
			return;
		}
		$current = trim( (string) get_post_meta( $post_id, 'guid', true ) );
		if ( '' === $current ) {
			update_post_meta( $post_id, 'guid', sanitize_text_field( $source_guid ) );
		}
	}

	private function sync_prices( $post_id, Accounting_Data $data ) {
		if ( ! class_exists( 'NovinCommerce_RolePrice_Roles' ) ) {
			return;
		}

		$role_map = $this->role_name_map();
		$explicit = array();
		foreach ( $data->role_price_rows() as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$name = isset( $row['WordPressRoleName'] ) ? trim( (string) $row['WordPressRoleName'] ) : '';
			$role = $this->resolve_role( $name, $role_map );
			$price = isset( $row['Price'] ) && is_numeric( $row['Price'] ) && (float) $row['Price'] > 0 ? (float) $row['Price'] : null;
			if ( '' === $role || null === $price ) {
				continue;
			}
			$explicit[ $role ] = wc_format_decimal( $price );
		}

		$legacy_prices = array();
		$roles          = array_keys( NovinCommerce_RolePrice_Roles::get_all_wp_roles() );
		foreach ( $roles as $role ) {
			$role = sanitize_key( $role );
			if ( '' === $role ) {
				continue;
			}
			$regular_key = NovinCommerce_RolePrice_Roles::regular_meta_key( $role );
			$sale_key    = NovinCommerce_RolePrice_Roles::sale_meta_key( $role );
			$origin_key  = '_novin_regular_origin_' . $role;
			$existing    = NovinCommerce_RolePrice_Roles::get_compatible_role_price( $post_id, $role, 'regular' );
			$sale        = get_post_meta( $post_id, $sale_key, true );

			if ( isset( $explicit[ $role ] ) ) {
				$value = $explicit[ $role ];
				update_post_meta( $post_id, $regular_key, $value );
				update_post_meta( $post_id, $origin_key, self::ORIGIN_ACCOUNTING );
				$legacy_prices[ $role ] = array( 'regular' => $value, 'sale' => is_scalar( $sale ) ? (string) $sale : '' );
			} elseif ( self::ORIGIN_ACCOUNTING === (string) get_post_meta( $post_id, $origin_key, true ) ) {
				// An explicitly accounting-owned role price may be cleared only when
				// the source no longer provides the role. Manual/legacy values survive.
				delete_post_meta( $post_id, $regular_key );
				delete_post_meta( $post_id, '_novin_regular_origin_' . $role );
				$legacy_prices[ $role ] = array( 'regular' => '', 'sale' => is_scalar( $sale ) ? (string) $sale : '' );
			} elseif ( is_numeric( $existing ) && (float) $existing > 0 ) {
				if ( '' === (string) get_post_meta( $post_id, $origin_key, true ) ) {
					update_post_meta( $post_id, $origin_key, self::ORIGIN_LEGACY );
				}
				$legacy_prices[ $role ] = array( 'regular' => wc_format_decimal( $existing ), 'sale' => is_scalar( $sale ) ? (string) $sale : '' );
			}
		}
		if ( ! empty( $legacy_prices ) ) {
			NovinCommerce_RolePrice_Roles::update_festi_role_prices( $post_id, $legacy_prices );
		}
	}

	private function sync_discount( $post_id, Accounting_Data $data ) {
		if ( ! class_exists( 'NovinCommerce_RolePrice_Roles' ) ) {
			return;
		}

		$state = $data->discount_state();
		$start = $data->discount_start_timestamp();
		$end   = $data->discount_end_timestamp();
		$roles = array_keys( NovinCommerce_RolePrice_Roles::get_all_wp_roles() );

		foreach ( $roles as $role ) {
			$role = sanitize_key( $role );
			if ( '' === $role ) {
				continue;
			}
			$sale_key    = NovinCommerce_RolePrice_Roles::sale_meta_key( $role );
			$origin_key  = '_novin_sale_origin_' . $role;
			$start_key   = '_novin_sale_start_' . $role;
			$end_key     = '_novin_sale_end_' . $role;
			$regular     = get_post_meta( $post_id, NovinCommerce_RolePrice_Roles::regular_meta_key( $role ), true );
			$existing_sale = get_post_meta( $post_id, $sale_key, true );
			$origin      = (string) get_post_meta( $post_id, $origin_key, true );

			// One-time safe migration for legacy discount-generated sales. Only
			// infer accounting ownership when the exact discount formula matches.
			if ( '' === $origin && is_numeric( $regular ) && is_numeric( $existing_sale ) && $data->discount_percent() > 0 ) {
				$expected = round( (float) $regular * ( 1 - ( $data->discount_percent() / 100 ) ), wc_get_price_decimals() );
				if ( abs( (float) $existing_sale - $expected ) < 0.000001 ) {
					$origin = self::ORIGIN_ACCOUNTING;
					update_post_meta( $post_id, $origin_key, $origin );
				}
			}

			if ( Accounting_Data::DISCOUNT_ACTIVE === $state && is_numeric( $regular ) && (float) $regular > 0 ) {
				$sale = $data->discount_sale_price( $regular );
				if ( null !== $sale ) {
					update_post_meta( $post_id, $sale_key, wc_format_decimal( $sale ) );
					update_post_meta( $post_id, $origin_key, self::ORIGIN_ACCOUNTING );
					if ( $start ) {
						update_post_meta( $post_id, $start_key, (string) $start );
					} else {
						delete_post_meta( $post_id, $start_key );
					}
					if ( $end ) {
						update_post_meta( $post_id, $end_key, (string) $end );
					} else {
						delete_post_meta( $post_id, $end_key );
					}
				}
			} elseif ( in_array( $state, array( Accounting_Data::DISCOUNT_EXPIRED, Accounting_Data::DISCOUNT_INVALID, Accounting_Data::DISCOUNT_NONE ), true ) && self::ORIGIN_ACCOUNTING === $origin ) {
				delete_post_meta( $post_id, $sale_key );
				delete_post_meta( $post_id, $origin_key );
				delete_post_meta( $post_id, $start_key );
				delete_post_meta( $post_id, $end_key );
				$this->clear_festi_sale( $post_id, $role );
			}
		}
	}

	private function clear_festi_sale( $post_id, $role ) {
		if ( ! class_exists( 'NovinCommerce_RolePrice_Roles' ) ) {
			return;
		}
		$data = NovinCommerce_RolePrice_Roles::get_festi_role_prices( $post_id );
		if ( ! is_array( $data ) ) {
			return;
		}
		$sales = isset( $data[ NovinCommerce_RolePrice_Roles::FESTI_SALE_KEY ] ) && is_array( $data[ NovinCommerce_RolePrice_Roles::FESTI_SALE_KEY ] )
			? $data[ NovinCommerce_RolePrice_Roles::FESTI_SALE_KEY ] : array();
		unset( $sales[ sanitize_key( $role ) ] );
		$data[ NovinCommerce_RolePrice_Roles::FESTI_SALE_KEY ] = $sales;
		$json = wp_json_encode( $data );
		if ( false !== $json ) {
			update_post_meta( $post_id, NovinCommerce_RolePrice_Roles::FESTI_META_KEY, $json );
		}
	}

	private function sync_accounting_levels( $post_id, Accounting_Data $data ) {
		$levels = $data->price_levels();
		update_post_meta( $post_id, '_novin_accounting_price_levels', wp_json_encode( $levels ) );
		update_post_meta( $post_id, '_novin_accounting_price_levels_count', (string) count( array_filter( $levels, function ( $row ) { return null !== $row['price']; } ) ) );
	}

	private function update_sync_marker( $post_id ) {
		$source_date = get_post_meta( $post_id, '_np-api-sync-date', true );
		$timestamp   = Accounting_Data::parse_timestamp( $source_date );
		if ( $timestamp ) {
			update_post_meta( $post_id, self::SYNC_MARKER_META, (string) $timestamp );
		}
	}

	private function role_name_map() {
		$map = array();
		foreach ( array_keys( \NovinCommerce_RolePrice_Roles::get_all_wp_roles() ) as $role ) {
			$role = sanitize_key( $role );
			if ( '' !== $role ) {
				$map[ strtolower( $role ) ] = $role;
			}
		}
		foreach ( \NovinCommerce_RolePrice_Roles::get_all_wp_roles() as $role_key => $label ) {
			$role_key = sanitize_key( $role_key );
			if ( is_string( $label ) && '' !== trim( $label ) ) {
				$map[ strtolower( trim( $label ) ) ] = $role_key;
			}
		}
		return $map;
	}

	private function resolve_role( $name, array $map ) {
		$name = trim( (string) $name );
		if ( '' === $name ) {
			return '';
		}
		$key = strtolower( $name );
		if ( isset( $map[ $key ] ) ) {
			return sanitize_key( $map[ $key ] );
		}
		$sanitized = sanitize_key( $name );
		return isset( $map[ $sanitized ] ) ? sanitize_key( $map[ $sanitized ] ) : '';
	}

	/**
	 * Background migration used by v2.0.0. It is deliberately bounded so it
	 * never scans the entire catalog in one web request.
	 */
	public function migrate_existing_chunk( $limit = 25 ) {
		global $wpdb;
		$cursor = (int) get_option( 'novin_commerce_v2_migration_cursor', 0 );
		$limit  = max( 1, min( 50, (int) $limit ) );
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT p.ID FROM {$wpdb->posts} p WHERE p.ID>%d AND p.post_type IN ('product','product_variation') AND p.post_status IN ('publish','private','draft') AND EXISTS (SELECT 1 FROM {$wpdb->postmeta} m WHERE m.post_id=p.ID AND m.meta_key='WebPrd' AND m.meta_value<>'') ORDER BY p.ID ASC LIMIT %d",
				$cursor,
				$limit
			)
		);
		if ( empty( $ids ) ) {
			update_option( 'novin_commerce_v2_migration_cursor', 0, false );
			update_option( 'novin_commerce_v2_migration_complete', 1, false );
			return false;
		}
		foreach ( $ids as $id ) {
			// sync_product() owns the health-index update for the product
			// and its variations, so do not decode the same WebPrd twice.
			$this->sync_product( absint( $id ) );
			$cursor = absint( $id );
		}
		update_option( 'novin_commerce_v2_migration_cursor', $cursor, false );
		return true;
	}
}
