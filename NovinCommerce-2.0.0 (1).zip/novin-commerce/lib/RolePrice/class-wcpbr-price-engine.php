<?php


if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Role-price runtime engine.
 *
 * Canonical role prices are stored in the site's base accounting currency.
 * Prices are used exactly as stored. NovinCommerce does not perform any
 * Rial/Toman conversion at runtime or during product editing.
 */
class NovinCommerce_RolePrice_Price_Engine {

	const FILTER_PRIORITY = 999999;

	private $role_cache = null;
	private $has_role_price_cache = array();
	private $effective_price_cache = array();

	public function __construct() {
		$p = self::FILTER_PRIORITY;
		foreach ( array(
			'woocommerce_product_get_price',
			'woocommerce_product_get_regular_price',
			'woocommerce_product_get_sale_price',
			'woocommerce_product_variation_get_price',
			'woocommerce_product_variation_get_regular_price',
			'woocommerce_product_variation_get_sale_price',
		) as $filter ) {
			add_filter( $filter, array( $this, 'filter_price' ), $p, 2 );
		}
		add_filter( 'woocommerce_product_get_regular_price', array( $this, 'filter_regular_price' ), $p + 1, 2 );
		add_filter( 'woocommerce_product_get_sale_price', array( $this, 'filter_sale_price' ), $p + 1, 2 );
		add_filter( 'woocommerce_product_variation_get_regular_price', array( $this, 'filter_regular_price' ), $p + 1, 2 );
		add_filter( 'woocommerce_product_variation_get_sale_price', array( $this, 'filter_sale_price' ), $p + 1, 2 );
		add_filter( 'woocommerce_product_is_on_sale', array( $this, 'filter_is_on_sale' ), $p + 1, 2 );
		add_action( 'woocommerce_before_calculate_totals', array( $this, 'apply_price_in_cart' ), $p + 1, 1 );
		add_filter( 'woocommerce_get_price_html', array( $this, 'maybe_show_contact_us' ), $p + 2, 2 );
		add_filter( 'woocommerce_is_purchasable', array( $this, 'maybe_disable_purchase' ), $p + 2, 2 );
		add_filter( 'woocommerce_variation_is_purchasable', array( $this, 'maybe_disable_purchase' ), $p + 2, 2 );
		add_filter( 'woocommerce_add_to_cart_validation', array( $this, 'validate_add_to_cart' ), $p + 2, 4 );
		add_filter( 'woocommerce_variation_prices_price', array( $this, 'filter_variation_price' ), $p + 1, 2 );
		add_filter( 'woocommerce_variation_prices_regular_price', array( $this, 'filter_variation_regular_price' ), $p + 1, 2 );
		add_filter( 'woocommerce_variation_prices_sale_price', array( $this, 'filter_variation_sale_price' ), $p + 1, 2 );
		add_filter( 'woocommerce_get_variation_prices_hash', array( $this, 'add_role_to_price_hash' ), $p + 2, 3 );
	}

	private function get_role() {
		if ( null === $this->role_cache ) {
			$this->role_cache = class_exists( 'NovinCommerce_RolePrice_Roles' ) ? NovinCommerce_RolePrice_Roles::get_current_user_role() : null;
		}
		return $this->role_cache;
	}

	public function add_role_to_price_hash( $hash ) {
		$hash = is_array( $hash ) ? $hash : array();
		$hash[] = $this->get_role() ? $this->get_role() : 'no-role';
		return $hash;
	}

	private function is_known_role( $role ) {
		return is_string( $role ) && '' !== $role && class_exists( 'NovinCommerce_RolePrice_Roles' ) && array_key_exists( $role, NovinCommerce_RolePrice_Roles::get_roles() );
	}

	private function get_raw_price( $post_id, $role, $type ) {
		if ( ! $this->is_known_role( $role ) ) {
			return '';
		}
		$value = NovinCommerce_RolePrice_Roles::get_compatible_role_price( absint( $post_id ), $role, $type );
		return $this->valid_price( $value ) ? wc_format_decimal( $value ) : '';
	}

	private function valid_price( $value ) {
		return null !== $value && ! is_array( $value ) && ! is_object( $value ) && '' !== trim( (string) $value ) && is_numeric( $value ) && (float) $value > 0;
	}

	private function get_sale_state( $post_id, $role ) {
		$origin = (string) get_post_meta( $post_id, '_novin_sale_origin_' . sanitize_key( $role ), true );
		$start  = (int) get_post_meta( $post_id, '_novin_sale_start_' . sanitize_key( $role ), true );
		$end    = (int) get_post_meta( $post_id, '_novin_sale_end_' . sanitize_key( $role ), true );
		if ( 'accounting' !== $origin && ! $start && ! $end ) {
			return true;
		}
		$now = time();
		if ( $start && $now < $start ) {
			return false;
		}
		if ( $end && $now > $end ) {
			return false;
		}
		return true;
	}

	private function get_effective_raw( $post_id, $role ) {
		$key = absint( $post_id ) . ':' . $role;
		if ( array_key_exists( $key, $this->effective_price_cache ) ) {
			return $this->effective_price_cache[ $key ];
		}
		$regular = $this->get_raw_price( $post_id, $role, 'regular' );
		if ( '' === $regular ) {
			$this->effective_price_cache[ $key ] = null;
			return null;
		}
		$sale = $this->get_raw_price( $post_id, $role, 'sale' );
		if ( '' !== $sale && $this->get_sale_state( $post_id, $role ) && (float) $sale < (float) $regular ) {
			$this->effective_price_cache[ $key ] = $sale;
			return $sale;
		}
		$this->effective_price_cache[ $key ] = $regular;
		return $regular;
	}


	private function role_has_price_for_product( WC_Product $product, $role ) {
		$id = absint( $product->get_id() );
		$key = $id . ':' . $role;
		if ( array_key_exists( $key, $this->has_role_price_cache ) ) {
			return $this->has_role_price_cache[ $key ];
		}
		if ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_children() as $variation_id ) {
				if ( '' !== (string) $this->get_raw_price( $variation_id, $role, 'regular' ) ) {
					return $this->cache_role_price( $key, true );
				}
			}
			return $this->cache_role_price( $key, false );
		}
		return $this->cache_role_price( $key, '' !== (string) $this->get_raw_price( $id, $role, 'regular' ) );
	}

	private function cache_role_price( $key, $value ) {
		$this->has_role_price_cache[ $key ] = (bool) $value;
		return (bool) $value;
	}

	public function filter_price( $price, $product ) {
		$role = $this->get_role();
		if ( ! $role || ! $product instanceof WC_Product ) {
			return $price;
		}
		if ( $product->is_type( 'variable' ) ) {
			return $this->role_has_price_for_product( $product, $role ) ? $price : $this->contact_or_original( $price );
		}
		$effective = $this->get_effective_raw( $product->get_id(), $role );
		return null === $effective ? $this->contact_or_original( $price ) : $effective;
	}

	public function filter_regular_price( $price, $product ) {
		$role = $this->get_role();
		if ( ! $role || ! $product instanceof WC_Product ) {
			return $price;
		}
		if ( $product->is_type( 'variable' ) ) {
			return $price;
		}
		$regular = $this->get_raw_price( $product->get_id(), $role, 'regular' );
		return '' === $regular ? $this->contact_or_original( $price ) : $regular;
	}

	public function filter_sale_price( $price, $product ) {
		$role = $this->get_role();
		if ( ! $role || ! $product instanceof WC_Product || $product->is_type( 'variable' ) ) {
			return $price;
		}
		$sale = $this->get_raw_price( $product->get_id(), $role, 'sale' );
		if ( '' === $sale || ! $this->get_sale_state( $product->get_id(), $role ) ) {
			return '';
		}
		$regular = $this->get_raw_price( $product->get_id(), $role, 'regular' );
		if ( '' !== $regular && (float) $sale >= (float) $regular ) {
			return '';
		}
		return $sale;
	}

	public function filter_is_on_sale( $on_sale, $product ) {
		$role = $this->get_role();
		if ( ! $role || ! $product instanceof WC_Product ) {
			return $on_sale;
		}
		if ( $product->is_type( 'variable' ) ) {
			return $this->role_has_price_for_product( $product, $role ) ? $on_sale : false;
		}
		$regular = $this->get_raw_price( $product->get_id(), $role, 'regular' );
		$sale    = $this->get_raw_price( $product->get_id(), $role, 'sale' );
		return '' !== $regular && '' !== $sale && $this->get_sale_state( $product->get_id(), $role ) && (float) $sale < (float) $regular;
	}

	public function filter_variation_price( $price, $variation ) {
		return $this->filter_variation_component( $price, $variation, 'effective' );
	}

	public function filter_variation_regular_price( $price, $variation ) {
		return $this->filter_variation_component( $price, $variation, 'regular' );
	}

	public function filter_variation_sale_price( $price, $variation ) {
		return $this->filter_variation_component( $price, $variation, 'sale' );
	}

	private function filter_variation_component( $price, $variation, $type ) {
		$role = $this->get_role();
		if ( ! $role || ! $variation instanceof WC_Product ) {
			return $price;
		}
		$raw = $type === 'effective'
			? $this->get_effective_raw( $variation->get_id(), $role )
			: $this->get_raw_price( $variation->get_id(), $role, $type );
		if ( null === $raw || '' === $raw ) {
			return 'sale' === $type ? '' : $price;
		}
		if ( 'sale' === $type && ! $this->get_sale_state( $variation->get_id(), $role ) ) {
			return '';
		}
		return $raw;
	}

	private function contact_or_original( $price ) {
		if ( class_exists( 'NovinCommerce_RolePrice_Settings' ) && NovinCommerce_RolePrice_Settings::is_contact_us_enabled() ) {
			return '';
		}
		return $price;
	}

	public function apply_price_in_cart( $cart ) {
		if ( ! $cart instanceof WC_Cart || ( is_admin() && ! defined( 'DOING_AJAX' ) ) ) {
			return;
		}
		$role = $this->get_role();
		if ( ! $role ) {
			return;
		}
		foreach ( $cart->get_cart() as $cart_item ) {
			$product = isset( $cart_item['data'] ) && $cart_item['data'] instanceof WC_Product ? $cart_item['data'] : false;
			if ( ! $product ) {
				continue;
			}
			$raw = $this->get_effective_raw( $product->get_id(), $role );
			if ( null !== $raw ) {
				$product->set_price( $raw );
			}
		}
	}

	public function maybe_show_contact_us( $html, $product ) {
		$role = $this->get_role();
		if ( ! $role || ! $product instanceof WC_Product || $this->role_has_price_for_product( $product, $role ) || ! class_exists( 'NovinCommerce_RolePrice_Settings' ) || ! NovinCommerce_RolePrice_Settings::is_contact_us_enabled() ) {
			return $html;
		}
		return '<span class="wcpbr-contact-us">' . esc_html( NovinCommerce_RolePrice_Settings::get_contact_us_text() ) . '</span>';
	}

	public function maybe_disable_purchase( $purchasable, $product ) {
		$role = $this->get_role();
		if ( ! $role || ! $product instanceof WC_Product || ! class_exists( 'NovinCommerce_RolePrice_Settings' ) || ! NovinCommerce_RolePrice_Settings::is_contact_us_enabled() ) {
			return $purchasable;
		}
		return $this->role_has_price_for_product( $product, $role ) ? $purchasable : false;
	}

	public function validate_add_to_cart( $passed, $product_id, $quantity, $variation_id = 0 ) {
		$role = $this->get_role();
		if ( ! $role || ! class_exists( 'NovinCommerce_RolePrice_Settings' ) || ! NovinCommerce_RolePrice_Settings::is_contact_us_enabled() ) {
			return $passed;
		}
		$check_id = absint( $variation_id ? $variation_id : $product_id );
		$product  = $check_id ? wc_get_product( $check_id ) : false;
		if ( ! $product || $this->role_has_price_for_product( $product, $role ) ) {
			return $passed;
		}
		wc_add_notice( esc_html( NovinCommerce_RolePrice_Settings::get_contact_us_text() ), 'error' );
		return false;
	}
}
