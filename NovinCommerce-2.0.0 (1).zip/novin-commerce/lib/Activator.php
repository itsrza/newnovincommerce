<?php

/**
 * Fired during plugin activation
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Novin_Commerce
 * @subpackage Novin_Commerce/includes
 */

namespace Novinwp\Novin_Commerce;

use As247\WpEloquent\Application;
use As247\WpEloquent\Database\Schema\Blueprint;
use As247\WpEloquent\Support\Facades\DB;
use As247\WpEloquent\Support\Facades\Schema;
use Novinwp\Novin_Commerce\Common\SettingAPI;

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Novin_Commerce
 * @subpackage Novin_Commerce/includes
 * @author     Novinwp <info@npwp.ir>
 */
class Activator {

	const MAINTENANCE_HOOK = 'novin_commerce_daily_maintenance';
	const V2_BACKFILL_HOOK = 'novin_commerce_v2_backfill';
	const CURRENT_SCHEMA = '6';

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		Application::bootWp();
		self::createTables();
		self::setSettings();
		self::scheduleMaintenance();
		update_option( 'novin_commerce_schema_version', self::CURRENT_SCHEMA );
		self::scheduleV2Backfill();
		self::removeLegacyCurrencyConversionSetting();
	}

	public static function createTables() {

		if ( ! Schema::hasTable( 'novin_commerce_syncs' ) ) {
			Schema::create( 'novin_commerce_syncs', function ( Blueprint $table ) {
				$table->increments( 'id' );
				$table->bigInteger( 'item_id' );
				$table->enum( 'item_type', [ 'product', 'category', 'user', 'order', 'variation' ] );
				$table->timestamp( 'created_at' )->default( DB::raw( 'CURRENT_TIMESTAMP' ) );
				$table->timestamp( 'updated_at' )->default( DB::raw( 'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP' ) );
				$table->unique( [ 'item_id', 'item_type' ] );
			} );
		}

		if ( Schema::hasTable( 'novin_commerce_syncs' ) ) {
			try {
				if ( ! Schema::hasColumn( 'novin_commerce_syncs', 'priority' ) ) {
					Schema::table( 'novin_commerce_syncs', function ( Blueprint $table ) {
						$table->integer( 'priority' )->default( 0 );
					} );
				}
			} catch ( \Throwable $e ) {
				// A concurrent upgrade or an older schema adapter may report the
				// column as unavailable. The next request can retry safely.
			}
		}

		if ( ! Schema::hasTable( 'novin_commerce_sync_logs' ) ) {
			Schema::create( 'novin_commerce_sync_logs', function ( Blueprint $table ) {
				$table->increments( 'id' );
				$table->string( 'event_type', 50 );
				$table->string( 'status', 20 )->default( 'info' );
				$table->string( 'item_type', 30 )->nullable();
				$table->bigInteger( 'item_id' )->default( 0 );
				$table->text( 'message' )->nullable();
				$table->longText( 'context' )->nullable();
				$table->timestamp( 'created_at' )->default( DB::raw( 'CURRENT_TIMESTAMP' ) );
				$table->index( [ 'item_type', 'item_id' ] );
				$table->index( [ 'status', 'created_at' ] );
			} );
		}


		if ( ! Schema::hasTable( 'novin_commerce_health_items' ) ) {
			Schema::create( 'novin_commerce_health_items', function ( Blueprint $table ) {
				$table->increments( 'id' );
				$table->bigInteger( 'object_id' );
				$table->string( 'object_type', 20 );
				$table->tinyInteger( 'guid_present' )->default( 0 );
				$table->tinyInteger( 'source_guid_present' )->default( 0 );
				$table->tinyInteger( 'guid_match' )->default( 0 );
				$table->tinyInteger( 'webprd_valid' )->default( 0 );
				$table->tinyInteger( 'stale' )->default( 0 );
				$table->tinyInteger( 'inventory_known' )->default( 0 );
				$table->double( 'inventory_value', 20, 6 )->nullable();
				$table->string( 'structure_mode', 40 )->default( 'unknown' );
				$table->tinyInteger( 'multi_unit_ambiguous' )->default( 0 );
				$table->tinyInteger( 'accounting_price_levels' )->default( 0 );
				$table->tinyInteger( 'mapped_roles' )->default( 0 );
				$table->string( 'discount_state', 20 )->default( 'none' );
				$table->tinyInteger( 'discount_actionable' )->default( 0 );
				$table->timestamp( 'source_modified' )->nullable();
				$table->timestamp( 'site_sync' )->nullable();
				$table->string( 'health_status', 20 )->default( 'healthy' );
				$table->timestamp( 'updated_at' )->default( DB::raw( 'CURRENT_TIMESTAMP' ) );
				$table->unique( [ 'object_id', 'object_type' ] );
				$table->index( [ 'health_status', 'updated_at' ] );
				$table->index( [ 'structure_mode', 'object_type' ] );
			} );
		} else {
			try {
				if ( ! Schema::hasColumn( 'novin_commerce_health_items', 'source_guid_present' ) ) {
					Schema::table( 'novin_commerce_health_items', function ( Blueprint $table ) { $table->tinyInteger( 'source_guid_present' )->default( 0 ); } );
				}
				if ( ! Schema::hasColumn( 'novin_commerce_health_items', 'inventory_value' ) ) {
					Schema::table( 'novin_commerce_health_items', function ( Blueprint $table ) { $table->double( 'inventory_value', 20, 6 )->nullable(); } );
				}
			} catch ( \Throwable $e ) {
				// Retry on the next request.
			}
		}

		self::ensure_utf8_tables();
	}

	private static function ensure_utf8_tables() {
		global $wpdb;
		$charset = isset( $wpdb->charset ) && preg_match( '/^[a-z0-9_]+$/i', $wpdb->charset ) ? $wpdb->charset : 'utf8mb4';
		$collate = isset( $wpdb->collate ) && preg_match( '/^[a-z0-9_]+$/i', $wpdb->collate ) ? $wpdb->collate : '';
		foreach ( array( $wpdb->prefix . 'novin_commerce_sync_logs' ) as $table ) {
			$sql = "ALTER TABLE {$table} CONVERT TO CHARACTER SET {$charset}";
			if ( '' !== $collate ) {
				$sql .= " COLLATE {$collate}";
			}
			$wpdb->query( $sql ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared -- identifiers are plugin-owned and charset values are allow-listed.
		}
	}

	public static function maybeUpgrade() {
		Application::bootWp();
		$version = (string) get_option( 'novin_commerce_schema_version', '' );
		if ( $version !== self::CURRENT_SCHEMA ) {
			self::createTables();
			update_option( 'novin_commerce_schema_version', self::CURRENT_SCHEMA );
			delete_option( 'novin_commerce_v2_migration_complete' );
			delete_option( 'novin_commerce_v2_health_cursor' );
			delete_option( 'novin_commerce_v2_health_complete' );
			delete_option( 'novin_commerce_v2_migration_cursor' );
		}
		self::scheduleMaintenance();
		self::scheduleV2Backfill();
		self::removeLegacyCurrencyConversionSetting();
	}


	/**
	 * Remove the retired Rial/Toman conversion setting from the shared plugin
	 * settings array. Existing product and order prices are never guessed or
	 * modified by this cleanup.
	 *
	 * @return void
	 */
	private static function removeLegacyCurrencyConversionSetting() {
		$settings = SettingAPI::getAll();
		if ( ! is_array( $settings ) || ! array_key_exists( 'novin_toman_conversion_enabled', $settings ) ) {
			return;
		}

		unset( $settings['novin_toman_conversion_enabled'] );
		SettingAPI::replaceAll( $settings );
	}

	public static function scheduleMaintenance() {
		if ( ! wp_next_scheduled( self::MAINTENANCE_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::MAINTENANCE_HOOK );
		}
	}


	public static function scheduleV2Backfill() {
		if ( ! get_option( 'novin_commerce_v2_migration_complete', 0 ) && ! wp_next_scheduled( self::V2_BACKFILL_HOOK ) ) {
			wp_schedule_single_event( time() + 15, self::V2_BACKFILL_HOOK );
		}
	}

	public static function unscheduleMaintenance() {
		// Clear every copy in case an older release scheduled the hook more
		// than once; deactivation must not leave a background maintenance job.
		if ( function_exists( 'wp_clear_scheduled_hook' ) ) {
			wp_clear_scheduled_hook( self::MAINTENANCE_HOOK );
			wp_clear_scheduled_hook( self::V2_BACKFILL_HOOK );
			return;
		}
		$timestamp = wp_next_scheduled( self::MAINTENANCE_HOOK );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::MAINTENANCE_HOOK );
		}
		$backfill = wp_next_scheduled( self::V2_BACKFILL_HOOK );
		if ( $backfill ) {
			wp_unschedule_event( $backfill, self::V2_BACKFILL_HOOK );
		}
	}

	public static function run_maintenance() {
		if ( class_exists( '\Novinwp\Novin_Commerce\Common\SyncLog' ) ) {
			\Novinwp\Novin_Commerce\Common\SyncLog::prune( 30 );
		}
		if ( class_exists( '\Novinwp\Novin_Commerce\Digits\Common\Sms_Log' ) ) {
			\Novinwp\Novin_Commerce\Digits\Common\Sms_Log::prune( 30 );
		}
		if ( class_exists( '\Novinwp\Novin_Commerce\Digits\Common\Otp_Manager' ) ) {
			\Novinwp\Novin_Commerce\Digits\Common\Otp_Manager::prune( 2 );
		}
	}

	public static function setSettings() {
		if ( ! SettingAPI::get( 'woocommerce_analytics' ) ) {
			SettingAPI::set( 'woocommerce_analytics', 'off' );
		}
		if ( ! SettingAPI::get( 'api_url' ) ) {
			SettingAPI::set( 'api_url', 'https://novinrank.ir/' );
		}

		if ( false === get_option( 'novin_commerce_inventory_warehouse_guids', false ) ) {
			add_option( 'novin_commerce_inventory_warehouse_guids', array(), '', false );
		}

		// update Permalink
		add_rewrite_endpoint( 'novin-commerce-transactions', EP_PAGES );
		flush_rewrite_rules();
	}
}
