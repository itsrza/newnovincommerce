# NovinCommerce 2.0.0 — Upgrade Guide

## Before upgrade

- Take a full database backup and a copy of the site files.
- Test the package on staging before production.
- Confirm that the accounting API credentials are valid and stored only in the site's configuration.
- Review the accounting warehouse scope setting before relying on inventory totals.


## تغییر مهم واحد پول در 2.0.0

تنظیم قدیمی «تبدیل ریال به تومان» به‌طور کامل حذف شده است. NovinCommerce دیگر هیچ قیمت، تخفیف، قیمت نقش، سبد، تسویه‌حساب یا سفارش را بر اساس این تنظیم تقسیم یا ضرب نمی‌کند. در ارتقا، فقط کلید تنظیم قدیمی از تنظیمات افزونه حذف می‌شود و هیچ قیمت ذخیره‌شده‌ای به‌صورت حدسی تغییر داده نمی‌شود.

## What changes during migration

Version 2.0.0 builds a persistent Health Index and migrates existing `WebPrd` records in bounded chunks. The plugin does not intentionally scan the complete catalog in one web request.

Existing products are re-evaluated for:

- accounting GUID and site GUID state;
- valid `WebPrd` JSON;
- inventory based on `PrdAnbarRelation[].Amount`;
- Variable versus Multi-Unit structure;
- accounting price levels and explicit WordPress role mappings;
- accounting discount ownership and schedule;
- sync freshness.

## Important behavioral changes

### Variable products

A normal Variable Product does not keep a separate zero stock at the parent level. Variation stock is authoritative for purchasability.

### Multi-Unit

Multi-Unit is enabled only for an explicit unit structure. `V2Qt` and `V3Qt` are independent conversions.

### Pricing

`Sell1..Sell8` are accounting price levels. They are not eight WordPress roles. `PriceRoleList` is the explicit role mapping.

### Discounts

Expired accounting discounts are removed only when accounting ownership is established. Manual WooCommerce sale prices are preserved.

## Rollback

Do not roll back only the plugin files after a production migration. Restore the database backup together with the matching plugin version when a full rollback is required.
